/**
 * Main step definition. Add all glue code here in this class
 */
var myStepDefinitionsWrapper;
myStepDefinitionsWrapper = function () {


    'use strict';

    //this.Given(/^I go to the url for mobile$/, function (callback) {
    //    browser.driver.get("https://angularjs.org").then(function () {
    //        browser.ignoreSynchronization = true;
    //        //geSSOLogin();
    //        //TestHelper.geSSOLogin().then(function () {
    //        TestHelperPO.isElementPresent(element(by.id("navbar-main"))).then(function () {
    //            TestHelperPO.elementToBeClickable(element(by.xpath("//*[@id='navbar-main']/div/div/ul/li[1]/a"))).then(function () {
    //                TestHelperPO.elementToBeClickable(element(by.xpath("//*[@id='navbar-main']/div/div/ul/li[1]/ul/li[1]/a"))).then(function () {
    //                    TestHelperPO.isElementPresent(element(by.id("phonecat-tutorial-app"))).then(function () {
    //                        callback();
    //                    });
    //                });
    //            });
    //        });
    //    })
    //});

    this.Given(/^I go to the url for mobile$/, function (callback) {
        browser.driver.get("http://www.protractortest.org/#/").then(function () {
            browser.ignoreSynchronization = true;
            //geSSOLogin();
            //TestHelper.geSSOLogin().then(function () {
            //TestHelperPO.isElementPresent(element(by.id("body"))).then(function () {
                TestHelperPO.elementToBeClickable(element(by.xpath('/html/body/nav/div/div[1]/button'))).then(function () {
                    TestHelperPO.elementToBeClickable(element(by.id('drop4'))).then(function () {

                        TestHelperPO.elementToBeClickable(element(by.xpath('/html/body/nav/div/div[2]/div/ul/li[5]/ul/li[2]/a'))).then(function () {
                            TestHelperPO.elementToBeClickable(element(by.xpath('/html/body/nav/div/div[1]/button'))).then(function () {

                                console.log("Made it 3");


                                TestHelperPO.elementToBeClickable(element(by.id('searchInput'))).then(function () {
                                    console.log("Made it 5");

                                    TestHelperPO.sendKeys(element(by.id('searchInput')), "isSelected").then(function () {
                                        TestHelperPO.elementToBeClickable(element(by.id('toggle-menu-button')), "isSelected").then(function () {
                                            TestHelperPO.elementToBeClickable(element(by.cssContainingText('.child.ng-binding.depth-1', 'isSelected'))).then(function () {
                                                TestHelperPO.scrollIntoView(element(by.cssContainingText('h5', 'Code'))).then(function () {
                                                    TestHelperPO.isElementPresent(element(by.css('.api-title'))).then(function () {
                                                        browser.sleep(5000).then(function () {

                                                            callback();
                                                        })

                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        //})
    });


};
module.exports = myStepDefinitionsWrapper;









