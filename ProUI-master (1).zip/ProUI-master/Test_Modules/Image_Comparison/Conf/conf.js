exports.config = {

  params: {
    login: {
      baseUrl: 'https://stuf-rc.run.asv-pr.ice.predix.io/sample14'
    }
  },

  specs: ['./../Features/*.feature'],

  plugins: [{

    path: './../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js'

  }],

  capabilities: {
    browserName: 'chrome',
    count: 1,
    shardTestFiles: false,
    maxInstances: 1,
    chromeOptions: {
      args: ['--no-sandbox', '--test-type=browser']

    }

  },

  onPrepare: function() {

    TestHelperPO = require('proui-utils').TestHelperPO;
    TestHelper = require('ProUI-Utils').TestHelper;
    ElementManager = require('ProUI-Utils').ElementManager;
    Logger = require('ProUI-Utils').Logger // Create reports folder if it does not exist

    var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
    var mkdirp = require('mkdirp');
    var reportsPath = './Reports/';

    mkdirp(reportsPath, function(err) {
      if (err) {
        console.error(err);
      } else {}
    });

    chai = require('chai');
    expect = chai.expect;
    path = require('path');
    Cucumber = require('cucumber');
    fs = require('fs');
    cem = new ElementManager('./../../../Test_Modules/exports/repo.json');
    TestHelper.setElementManager(cem);
    browser.driver.manage().window().setSize(1280, 1440);

    protractorImageComparison = require('protractor-image-comparison');

    browser.protractorImageComparison = new protractorImageComparison(
        {
            baselineFolder: './Test_Modules/Image_Comparison/Test_Data_Pics',
            screenshotPath: './Test_Modules/Image_Comparison/Test_Data_Pics',
            autoSaveBaseline:true
        });
  },

  framework: 'custom',

  frameworkPath: require.resolve('protractor-cucumber-framework'),

  cucumberOpts: {

    require: [

      './../step_definitions/*',

      './../../../node_modules/proui-utils/Compressed_Utils/Reporter.js'

    ],

    tags: [],

    format: 'pretty'

  }
}