module.exports = function () {
    this.Given(/I go to the URL$/, function (callback) {
        browser.driver.get(browser.params.login.baseUrl);

        browser.driver.isElementPresent(by.xpath('//*[@value="Sign in"]')).then(function (bool) {

            browser.ignoreSynchronization = true;

            TestHelper.assertTrue(bool, callback);

            callback();

        });

    });
    this.Given(/^I check the image at the homepage$/, function (callback) {

        //Navigate to element you want to compare
        TestHelper.sendKeys('Predix_ProUI_TestPage', 'Predix_ProUI_Object_0', 'neoteric-matrix').then(function () {
            TestHelper.sendKeys('Predix_ProUI_TestPage', 'Predix_ProUI_Object_1', 'neo@2017').then(function () {
                TestHelper.elementToBeClickable('Predix_ProUI_TestPage', 'Predix_ProUI_Object_2').then(function () {
                    TestHelper.isElementPresent(element(by.css('.pxh-drawer-header'))).then(function () {

                        //Provide the element that needs to be checked, and a name for the image
                        browser.protractorImageComparison.checkElement(element(by.css('.pxh-drawer-header')), 'test').then(function (percentDifferent) {

                            //The function returns a promise with the percentage that shows difference
                            console.log("The difference: " + percentDifferent)

                            //Asserting if the percentage is 0 meaning that there are no differences between the two images
                            TestHelper.assertEqual(0, percentDifferent, callback)
                            callback();
                        });
                    });
                });
            });
        });
    });


}