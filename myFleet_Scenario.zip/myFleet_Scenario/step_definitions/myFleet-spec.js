var currentPage = 'taskMgmtPage';

module.exports = function() {

      this.Given(/^I login to (.*)$/, function (env, callback) {
		env = browser.params.login.url;
		taskMgmtPage.getLogin(env).then(function (completed) {
			browser.ignoreSynchronization = true;
			assert.isTrue(completed, 'Not login page');
			callback();
		});
	});
	this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username;
		password = browser.params.login.password;
		taskMgmtPage.setName(userName).then(function () {
			taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});

	this.When(/^I can able to navigate into MyFleet application (.*)$/, function (userName, callback) {
		userName = browser.params.login.username;
		//password = browser.params.login.password;
		taskMgmtPage.setName1(userName).then(function () {
			//taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin1().then(function () {
					callback();
				});
			//});
		});
	});

	this.Given(/^I can able to Launch the MyFleet application$/, function(callback) {
        taskMgmtPage.getLoginIndex().then(function () {
                         callback();
		});
	});

	/*this.Then(/^I can able to Launch the MyFleet application$/, function(callback) {
        taskMgmtPage.getLogin1().then(function () {
                         callback();
		});
	});*/

	this.Given(/^I can able to enter SSO$/, function(callback) {
        taskMgmtPage.enterSSO().then(function () {
                         callback();
		});
	});
	

	this.Then(/^I can able to click on Login button$/, function(callback) {
        taskMgmtPage.loginButton().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to see Myfleet Assets Management Tab$/, function(callback) {
        taskMgmtPage.waitForAssetsTab().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to click on Assets Management Tab$/, function(callback) {
        taskMgmtPage.assetsTab().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to click on Cases Management Tab$/, function(callback) {
        taskMgmtPage.casesTab().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to validate cases header$/, function(callback) {
        taskMgmtPage.casesHeaderTxt().then(function (value) {
		assert.equal(value, 'M&D Cases');
		console.log("Cases Header Text: " + value);
                         callback();
		});
	});

	this.Then(/^I can able to click on Billing Management Tab$/, function(callback) {
        taskMgmtPage.billingTab().then(function () {
                         callback();
		});
	});

	this.When(/^I can able to wait for Billing Management Tab$/, function(callback) {
        taskMgmtPage.waitForBillingTab().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to validate Billing header$/, function(callback) {
        taskMgmtPage.billingHeaderTxt().then(function (value) {
		assert.equal(value, 'CSA Billing');
		console.log("Billing Header Text: " + value);
                         callback();
		});
	});

	this.Then(/^I can able to click on UserName$/, function(callback) {
        taskMgmtPage.userNameTxt().then(function () {
                         callback();
		});
	});
	this.Then(/^I can able to search with Contract ID$/, function (callback) {
		taskMgmtPage.myContactsSearchFld().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to click on Setting and Mysetting tabs$/, function(callback) {
        taskMgmtPage.mySetting().then(function () {
                         callback();
		});
	});
	this.Then(/^I can able to search with Site name$/, function(callback) {
        taskMgmtPage.mySitesSearchKey().then(function () {
                         callback();
		});
	});

	this.Given(/^I can able to select the Site$/, function (callback) {
        taskMgmtPage.siteModuleSel(callback);
	});
	
	this.Then(/^I can able to click on Site Apply button$/, function(callback) {
        taskMgmtPage.mySitesApplyBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I can able to validate added site message$/, function(callback) {
        taskMgmtPage.mySitesAddConformationMsg().then(function (value) {
			assert.equal(value, 'My Sites updated successfully.');
		console.log("Text: "+ value);
                         callback();
		});
	});
	this.Then(/^I can able to click on Terms and Condition or Edit button$/, function(callback) {
        taskMgmtPage.tccViewandEditBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I can able to validate Terms and Condition page header Text$/, function(callback) {
        taskMgmtPage.termsAndCondtionpageHeader().then(function (value) {
			assert.equal(value, 'Contract Terms and Conditions');
		console.log("Terms&Condition page headerText: "+ value);
                         callback();
		});
	});
	this.Then(/^I can able to click on Create new version button$/, function(callback) {
        taskMgmtPage.createNewVersionBtn().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to enter Create new version description$/, function(callback) {
        taskMgmtPage.createVersionDesc().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to click on Create new version commit button$/, function(callback) {
		taskMgmtPage.validateNoRecord(callback);
	});
	this.Then(/^I can able to click on Create new version commit button$/, function(callback) {
        taskMgmtPage.createNewVersionCommitBtn().then(function () {
                         callback();
		});
	});	

	this.Then(/^I can able to click on Billing commit button$/, function(callback) {
        taskMgmtPage.billingCommitBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I can able to validate Billing conformation commit Text$/, function(callback) {
        taskMgmtPage.billingConformationCommitTxt().then(function (value) {
			//assert.equal(value, 'My Sites updated successfully.');
		console.log("Billing conformation commitText: "+ value);
                         callback();
		});
	});
	this.Then(/^I can able to click on billing conformation commit button$/, function(callback) {
        taskMgmtPage.billingConformationCommitBtn().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to validate Data commited success message$/, function(callback) {
		taskMgmtPage.billingConformationCommitMessage().then(function (value) {
			browser.sleep(8000);	
		assert.equal(value, 'Data Committed Successfully');
		console.log("Success message: "+ value);
			callback();
		});
	});
	this.Then(/^I can able to wait Data commited success message$/, function(callback) {
        taskMgmtPage.waitForbillingConformationCommitMessage().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to validate Data Saved success message$/, function(callback) {
		taskMgmtPage.billingConformationCommitMessage().then(function (value) {
			browser.sleep(8000);	
		assert.equal(value, 'Data Saved Successfully');
		console.log("Success message: "+ value);
			callback();
		});
	});

	this.Then(/^I can able to click on billing back button$/, function(callback) {
        taskMgmtPage.billingbackbtnheader().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to validate Billing schedule Header Text$/, function(callback) {
        taskMgmtPage.billingScheduleHeaderTxt().then(function (value) {
			assert.equal(value, 'Billing Schedule');
		console.log("Billing schedule Header Text: "+ value);
                         callback();
		});
	});

	this.Then(/^I can able to select from date in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIcon().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to select To date in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleToDateCalenarIcon().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to search Fixed and Variable contract in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForFixed().then(function () {
			 callback();
		});
	});
	this.Then(/^I can able to select specific date range in Billing schedule section$/, function(callback) {
		taskMgmtPage.billingScheduleFromDateCalenar().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to search Milestone contract in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForMilestone().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to select from date for Multi Project Id in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForMultiProjectID().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to reset from date in Billing schedule Filter$/, function(callback) {
		taskMgmtPage.billingScheduleDateCalenarSet().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to click on Billing schedule filter Apply button$/, function(callback) {
		taskMgmtPage.billingScheduleFilterApplyBtn().then(function () {
			 callback();
		});
	});	

	this.Then(/^I can able to validate Billing schedule filter records count$/, function(callback) {
		taskMgmtPage.billingScheduleRecordsCount(callback);
			//callback();
		//});
	});

	this.Then(/^I can able to validate Billing schedule Period and Event Text$/, function(callback) {
		taskMgmtPage.billingSchedulePeriodEventTxt().then(function (value) {
				//assert.equal(value, 'Billing Schedule');
			console.log("Billing schedule Period/Event Text: "+ value);
				 callback();
			});
		});

	this.Then(/^I can able to select Contract Level and Other Required fields$/, function(callback) {
		taskMgmtPage.validateContractLevel(callback);
	});

	this.Then(/^I can able to search Billing schedule records of the contractor$/, function(callback) {
		taskMgmtPage.billingScheduleFilterSearchFld().then(function () {
			 callback();
		});
	});
	this.Then(/^I can able to click on billing schedule Calculate button$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateBtn().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Contractor check box$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateConfChkBtn().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Calculate yes button$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateConfOkBtn().then(function () {
			 callback();
		});
	});
	this.Then(/^I can able to validate Billing schedule Calculate unit SN header Text$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnTxt().then(function (value) {
		assert.equal(value, 'UNIT SN');
		console.log("Billing schedule UNIT SN header Text: "+ value);
			callback();
		});
	});
	this.Then(/^I can able to validate Billing schedule calculate Unit SN Value for Contract Level$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnValue().then(function (value) {
		assert.equal(value, 'All');
		console.log("Billing schedule UNIT SN Value: "+ value);
			callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Calculate Back button$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateBackBtn().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to select Individual equipment level and Other Required Fields$/, function(callback) {
		taskMgmtPage.validateIndividualRecords(callback);
	});

	this.Then(/^I can able to validate Billing schedule calculate Unit SN Value for Individual equipment$/, function(callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnValue().then(function (value) {
		//assert.equal(value, 'All');
		console.log("Billing schedule UNIT SN Value: "+ value);
			callback();
		});
	});

	this.Then(/^I can able to validate Invoice frequency, when user selects any Fee applicable frequency$/, function(callback) {
		taskMgmtPage.validateInvoiceFrequency(callback);
	});

	this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Monthly$/, function(callback) {
		taskMgmtPage.validateMonthlyInvoiceFrequency(callback);
	});
	
	this.Then(/^I can validate application frequency and Invoice Frequency Text$/, function (callback) {
		taskMgmtPage.billingScheduleEventPeriodTxt().then(function(){
				callback();
		});
});

this.Then(/^I can validate application frequency and Invoice Frequency is Monthly$/, function (callback) {
	taskMgmtPage.verifyMonthlyFrequencyCurrentDate().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Quarterly$/, function(callback) {
	taskMgmtPage.validateQuarterlyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Quarterly$/, function (callback) {
	taskMgmtPage.billingScheduleQuarterlyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Semi-Annually$/, function(callback) {
	taskMgmtPage.validateSemiannuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Semi-Annually$/, function (callback) {
	taskMgmtPage.billingScheduleSemiannuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Annually$/, function(callback) {
	taskMgmtPage.validateAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Annually$/, function (callback) {
	taskMgmtPage.billingScheduleAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Quarterly$/, function(callback) {
	taskMgmtPage.validateQuarterlyQuarterlyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Quarterly$/, function (callback) {
	taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Semi Annually$/, function(callback) {
	taskMgmtPage.validateQuarterlySemiAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Semi Annually$/, function (callback) {
	taskMgmtPage.billingScheduleQuarterlySemiAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Annually$/, function(callback) {
	taskMgmtPage.validateQuarterlyAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Annually$/, function (callback) {
	taskMgmtPage.billingScheduleQuarterlyAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Semi Annually and Invoice Frequency is Semi Annually$/, function(callback) {
	taskMgmtPage.validateSemiAnnuallySemiAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Semi Annually and Invoice Frequency is Semi Annually$/, function (callback) {
	taskMgmtPage.billingScheduleSemiAnnuallySemiAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Semi Annually and Invoice Frequency is Annually$/, function(callback) {
	taskMgmtPage.validateSemiAnnuallyAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Semi Annually and Invoice Frequency is Annually$/, function (callback) {
	taskMgmtPage.billingScheduleSemiAnnuallyAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to select fee application frequency is Annually and Invoice Frequency is Annually$/, function(callback) {
	taskMgmtPage.validateAnnuallyAnnuallyInvoiceFrequency(callback);
});

this.Then(/^I can validate application frequency Annually and Invoice Frequency is Annually$/, function (callback) {
	taskMgmtPage.billingScheduleAnnuallyAnnuallyEventPeriodTxt().then(function(){
			callback();
	});
});

this.Then(/^I can able to verify how invoice Date is getting generated when Invoicing Frequency is selected Monthly$/, function(callback) {
	taskMgmtPage.validateMonthlyActualDate30InvoiceFrequency(callback);
});

this.Then(/^I can validate Invoice Date$/, function (callback) {
	taskMgmtPage.billingScheduleInvoiceTxt().then(function(){
			callback();
		});
	});

	this.Then(/^I can validate Invoice Date and Entitlement Date and Invoice Frequency is Monthly$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEntitlementDate().then(function(){
				callback();
			});
		});

		this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly-Month post billing period close$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyEntitlementMonth1().then(function(){
					callback();
				});
			});

		this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyEntitlementMonth().then(function(){
					callback();
				});
			});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and 2nd Month post billing period close$/, function(callback) {
			taskMgmtPage.validateMonthlyActualDate31InvoiceFrequency(callback);
		});

		this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly-Current billing month$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyEntitlementCurrentMonth().then(function(){
					callback();
				});
			});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and Current billing month$/, function(callback) {
			taskMgmtPage.validateMonthlyInvoiceFrequencyCurrentWithinBilling(callback);
		});
		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and Within No estimation required$/, function(callback) {
			taskMgmtPage.validateMonthlyInvoiceFrequencyNoEstimationRequired(callback);
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and After billing period$/, function(callback) {
			taskMgmtPage.validateQuarterlyInvoiceFrequencyAfterBilling(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Quarterly and After billing period$/, function (callback) {
			taskMgmtPage.billingScheduleSemiAnnuallySemiAnnuallyEventPeriodTxt().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 2nd Month- After billing period$/, function(callback) {
			taskMgmtPage.validateQuarterlyInvoiceFrequencyAfterBilling2ndMonth(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Quarterly, Entitlement and Event Month$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyEntitlementMonth().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 1st Month, Deviation-1, Within Estimation required$/, function(callback) {
			taskMgmtPage.validateQuarterlyInvoiceFrequencyWithinBilling1stMonth(callback);
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 2nd Month, Deviation-1, Within-without Estimation$/, function(callback) {
			taskMgmtPage.validateQuarterlyInvoiceFrequencyWithinBilling2ndtMonth(callback);
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually and Month post billing period, After end of billing period$/, function(callback) {
			taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Semi Annually and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth().then(function(){
					callback();
			});
		});

		this.Then(/^I can validate application and Invoice frequency Semi Annually 2nd Month and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlement2ndMonth().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually and 2nd Month post billing period, After end of billing period$/, function(callback) {
			taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Annually and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually and Month post billing period, After end of billing period$/, function(callback) {
			taskMgmtPage.validateAnnuallyInvoiceFrequencyAfterBilling(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Annually 2nd Month and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlement2ndMonth().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually and 2ndMonth post billing period, After end of billing period$/, function(callback) {
			taskMgmtPage.validateAnnuallyInvoiceFrequencyAfterBilling2ndMonth(callback);
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually, Month post billing and Actual day 30th$/, function(callback) {
			taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyDeviation0After(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Semi Annually, Actual day 30th and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth30th().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually, 2nd Month post billing and Actual day 30th$/, function(callback) {
			taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth30th(callback);
		});

		this.Then(/^I can validate application and Invoice frequency Semi Annually, Actual day 30th, Deviation-1, and After billing period$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyEntitlementMonthDeviation1().then(function(){
					callback();
			});
		});

		this.Then(/^I can validate application and Invoice frequency Annually, Actual day 30th and After billing period$/, function (callback) {
			taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth30th().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually, 1st Month post billing and Actual day 30th$/, function(callback) {
			taskMgmtPage.validateAnnuallyInvoiceFrequency30thAfterBilling(callback);
		});

		this.Then(/^I can verify the My Contracts title is (.*)$/, function (myContractsHeader,callback) {
			taskMgmtPage.verifyMyContractsTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsHeader, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the Billing Schedule Title is (.*)$/, function (billingSchedule,callback) {
			taskMgmtPage.verifyBillingScheduleTitle().then(function (value) {
				TestHelper.assertEqual(value,billingSchedule, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the Outage Schedule Title is (.*)$/, function (outageSchedule,callback) {
			taskMgmtPage.verifyOutageScheduleTitle().then(function (value) {
				TestHelper.assertEqual(value,outageSchedule, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts Customers Title is (.*)$/, function (myContractsCustomers,callback) {
			taskMgmtPage.verifyMyContractsCustomersTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsCustomers, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts Contract Title is (.*)$/, function (myContractsContract,callback) {
			taskMgmtPage.verifyMyContractsContractTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsContract, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts ModuleID Title is (.*)$/, function (myContractsModuleID,callback) {
			taskMgmtPage.verifyMyContractsModelIDTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsModuleID, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts Site Title is (.*)$/, function (myContractsSite,callback) {
			taskMgmtPage.verifyMyContractsSiteTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsSite, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts Status Title is (.*)$/, function (myContractsStatus,callback) {
			taskMgmtPage.verifyMyContractsStatusTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsStatus, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts OpData Title is (.*)$/, function (myContractsOpData,callback) {
			taskMgmtPage.verifyMyContractsOpDataTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsOpData, callback);
				callback();
			});
	
		});
		this.Then(/^I can verify the MyContracts TandCs Title is (.*)$/, function (myContractsTandCs,callback) {
			taskMgmtPage.verifyMyContractsTandCsTitle().then(function (value) {
				TestHelper.assertEqual(value,myContractsTandCs, callback);
				callback();
			});	
		});

		this.Then(/^I can able to select Billing calculation with Escalation, same rate and other terms and conditions$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationForSameRate(callback);
		});

		this.Then(/^I can verify the Billing calculation with Escalation and Same Escalation rate applied for all billing types$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyEscalationForSame().then(function(){
					callback();
			});
		});

		this.Then(/^I can verify the Total Amount of Billing calculation with Escalation$/, function (callback) {
			taskMgmtPage.verifyTotalBillableAmount().then(function(){
					callback();
			});
		});

		this.Then(/^I can validate the Total Amount of Billing calculation with Escalation$/, function (callback) {
			taskMgmtPage.billingScheduleInvoiceAmountTxt().then(function(){
					callback();
			});
		});
		this.Then(/^I can wait for the Total Amount of Billing calculation with Escalation$/, function (callback) {
			taskMgmtPage.waitForbillingScheduleInvoiceAmountTxt().then(function(){
					callback();
			});
		});

		this.Then(/^I can validate the Total Amount of Billing calculation with Escalation for different period$/, function (callback) {
			taskMgmtPage.quarterBillingScheduleInvoiceAmountTxt().then(function(){
					callback();
			});
		});

		this.Then(/^I can validate the Total Amount of Billing calculation$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyTotalAmountTxt().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to select Billing calculation with Escalation, Different and other terms and conditions$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationForDifferentRate(callback);
		});
		this.Then(/^I can verify the Billing calculation with Escalation and Different Escalation rate applied for all billing types$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyEscalationForDifferent().then(function(){
					callback();
			});
		});

		this.Then(/^I can verify the Billing calculation with Different Escalation rate applied for all Monthly Variable billing types$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyEscalationForDifferent().then(function(){
					callback();
			});
		});
		this.Then(/^I can verify the Billing calculation with Different Escalation rate applied for all Monthly billing types$/, function (callback) {
			taskMgmtPage.verifyMonthlyFrequencyEscalationForDifferent1().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to click on Ops Data view edit button$/, function (callback) {
			taskMgmtPage.billingOpsDataViewBtn().then(function(){
					callback();
			});
		});

		/*this.Then(/^I can able to select the from and To date range$/, function (callback) {
			taskMgmtPage.billingOpsDataFromCalendarIcon().then(function(){
					callback();
			});
		});*/

		this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function (callback) {
			taskMgmtPage.approve1stRecords().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function(callback) {
			taskMgmtPage.approve1stRecords(callback);
		});

		this.Then(/^I can able to click on Ops data Billing back button$/, function (callback) {
			taskMgmtPage.billingOpsBackToBillingBtn().then(function(){
					callback();
			});
		});

		/*this.Then(/^I can able to validate the Quarter and click on Calculate button$/, function(callback) {
			taskMgmtPage.quarterRequestAccess(callback);
		});*/

		this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function(callback) {
			taskMgmtPage.approve1stRecords(callback);
		});
		this.Then(/^I can able to validate the Quarter and click on Calculate button$/, function (callback) {
			taskMgmtPage.quarterRequestAccess().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to select Billing calculation with Escalation, with same rate for all billing types for different period$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationForSameRateDifferentPeriod(callback);
		});
		this.Then(/^I can able to select Billing calculation with Escalation, same rate for all billing types for different Monthly period$/, function(callback) {
			taskMgmtPage.validateMonthlyBillingEscalationForSameRateDifferentPeriod(callback);
		});
		/*this.Then(/^I can able to select Billing calculation with Escalation, with same rate for all billing types for different period$/, function (callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationForSameRateDifferentPeriod().then(function(){
					callback();
			});
		});*/

		this.Then(/^I can verify the Invoice when Escalation be applied & displayed as separate line of calculation with Escalation rate$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyEscalationSeparateLine().then(function(){
					callback();
			});
		});

		this.Then(/^I can able to select Billing calculation with Escalation, 100FFH with 25 escalation will show as 125FFH$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationFor125(callback);
		});
		this.Then(/^I can able to click on Variable billing schedule Calculate button$/, function (callback) {
			taskMgmtPage.quarterVariableCalculateButton().then(function(){
					callback();
			});
         });


		this.Then(/^I can verify the Invoice when Escalation be applied to the billing rates FFH$/, function (callback) {
				taskMgmtPage.verifyQuarterlyFrequencyFFHEscalation().then(function(){
						callback();
			});
		});

		this.Then(/^I can able to select Billing calculation with Escalation and Show escalation by unit by billing type$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationlowestLevelOfDetail(callback);
		});

		this.Then(/^I can able to select Billing calculation with Escalation and Show escalation by unit by billing type for Individual$/, function(callback) {
			taskMgmtPage.validateQuarterlyBillingEscalationlowestLevelOfIndividualDetail(callback);
		});

		this.Then(/^I can verify the Invoice when Escalation by unit by billing type for Individual$/, function (callback) {
			taskMgmtPage.verifyQuarterlyFrequencyFFHEscalation().then(function(){
					callback();
		});
	});

	this.Then(/^I can able to Verify the Unit id data$/, function (callback) {
		taskMgmtPage.billingScheduleOpsDataUnitIdTxt().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to Validate the Unit id in Escation description$/, function (callback) {
		taskMgmtPage.verifyQuarterlyEscalationUnitIDTxt().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to Validate Contract level the Unit id in Escation description$/, function (callback) {
		taskMgmtPage.escalationBillingVariableTypeTxt().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to search with Variable and Contract ID$/, function(callback) {
		taskMgmtPage.billingScheduleSearchFld().then(function () {
			 callback();
		});
	});

	this.Then(/^I can able to validate Variable description text$/, function(callback) {
        taskMgmtPage.escalationBillingVariableType().then(function () {
                         callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and Combine all escalation into one line$/, function(callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationCombineDetail(callback);
	});

	this.Then(/^I can able to Validate the Escation description count$/, function (callback) {
		taskMgmtPage.escalationBillingTypeCount().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to search with Multi Project Contract ID$/, function (callback) {
		taskMgmtPage.myMultiProjectContactSearchFld().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and multiple Project IDs billing split by Site$/, function(callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationSplitbySite(callback);
	});

	this.Then(/^I can able to verify Equipment and Project IDs$/, function (callback) {
		taskMgmtPage.validationOfEquipmentAndProjectId().then(function(){
				callback();
		});
	});
	this.Then(/^I can able to verify Project IDs$/, function (callback) {
		taskMgmtPage.validationOfEquipmentAndProject().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to Validate the Multi Equipment and Project ids count$/, function (callback) {
		taskMgmtPage.validationProjectAndEquipmentIdTxt1().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to Validate the Multi Equipment and Project ids percentage$/, function (callback) {
		taskMgmtPage.validationProjectAndEquipmentId().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and multiple Project IDs billing split by Site Percentage$/, function(callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationSplitbySitePercentage(callback);
	});

	this.Then(/^I can able to select Billing calculation with new description template for Fixed Billing$/, function(callback) {
		taskMgmtPage.validateQuarterlyFixedBillingDescriptionTmplate(callback);
	});

	this.Then(/^I can able to Validate the new description template for Fixed and Variable Billing$/, function (callback) {
		taskMgmtPage.fixedVariableBillingDescriptionTemplate().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to Validate the new description template for Milestone Billing$/, function (callback) {
		taskMgmtPage.milestoneBillingDescriptionTemplate().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Fixed billing amount for the entire contract$/, function(callback) {
		taskMgmtPage.validateFixedBillingAmountForEntireContract(callback);
	});

	this.Then(/^I can able to validate the fixed billing amount for the entire contract$/, function (callback) {
		taskMgmtPage.validateInvoiceFixedBillingAmountForEntireContract().then(function(){
				callback();
		});
	});
	this.Then(/^I can able to select Billing calculation with Fixed billing amount for different date ranges$/, function(callback) {
		taskMgmtPage.validateFixedBillingAmountForDifferentDateRanges(callback);
	});

	this.Then(/^I can able to validate the fixed billing amount for different date ranges$/, function (callback) {
		taskMgmtPage.validateInvoiceFixedBillingAmountForEntireContract().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to search with Quarter and Contract id (.*)$/, function (actionTitle,callback) {
        taskMgmtPage.createActionTitle(actionTitle).then(function () {
            callback();
        });
	});
	
	this.Then(/^I can able to search with Monthly and Contract id (.*)$/, function (actionTitle,callback) {
        taskMgmtPage.createActionTitle(actionTitle).then(function () {
            callback();
        });
	});

	this.Then(/^I can able to search with Monthly Contract id (.*)$/, function (actionTitle1,callback) {
        taskMgmtPage.createActionTitle1(actionTitle1).then(function () {
            callback();
        });
	});
	
	this.Then(/^I can able to search with Non Monetized Contract id (.*)$/, function (actionTitle1,callback) {
        taskMgmtPage.createActionTitle1(actionTitle1).then(function () {
            callback();
        });
	});

	this.Then(/^I can able to search with Fixed Non Monetized Contract id (.*)$/, function (actionTitle2,callback) {
        taskMgmtPage.createActionTitle2(actionTitle2).then(function () {
            callback();
        });
	});

	this.Then(/^I can able to search with Fixed Monetized Contract id (.*)$/, function (actionTitle3,callback) {
        taskMgmtPage.createActionTitle3(actionTitle3).then(function () {
            callback();
        });
	});
	
	this.Then(/^I can able to select Billing calculation with No Fixed billing$/, function(callback) {
		taskMgmtPage.validateNoFixedBilling1(callback);
	});

	this.Then(/^I can able to clear the search data from Billing schedule search field$/, function(callback) {
		taskMgmtPage.billingScheduleSearchFldClear(callback);
	});

	this.Then(/^I can able to validate the No fixed billing amount$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with One rate across the entire contract timeline in Variable billing$/, function(callback) {
		taskMgmtPage.validateNoFixedBilling1(callback);
	});

	this.Then(/^I can able to validate the One rate across the entire contract timeline in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to validate the Different rates for different fuel type for Quarterly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling1().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to validate the Different rates for different fuel type for Monthly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Different rates across different time period in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableDifferentRatesAcrossDifferentTimePeriods(callback);
	});

	this.Then(/^I can able to validate the Different rates across different time period in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Different rates across different range of operations in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableDifferentRatesAcrossDifferentRangeofOperations(callback);
	});

	this.Then(/^I can able to select Monthly Billing calculation with Different rates for different fuel type in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableMonthlyDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to select Quartely Billing calculation with Different rates for different fuel type in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableQuartelyDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to delete created rows in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableBillingWidgetDelectRows(callback);
	});

	this.Then(/^I can able to delete created rows in Terms and Conditions billing$/, function (callback) {
		taskMgmtPage.validateTermsAndConditionsBillingWidgetDelectRows(callback);
	});

	this.Then(/^I can able to select Anually Billing calculation with Different rates for different fuel type in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableAnuallyYesDifferentRatesForDifferentFuelType(callback);
	});
	this.Then(/^I can able to validate the Different rates for different fuel type for Anually in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling1().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Anually Billing calculation with Different rates for different fuel type and No rate based on ops range in Variable billing$/, function(callback) {
		taskMgmtPage.validateVariableAnuallyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Anually in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function(){
				callback();
		});
	});
	this.Then(/^I can able to select Quarterly Billing calculation with Different rates for different fuel type and No rate based on ops range$/, function(callback) {
		taskMgmtPage.validateVariableQuarterlyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Quarterly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Monthly Billing calculation with Different rates for different fuel type and No rate based on ops range$/, function(callback) {
		taskMgmtPage.validateVariableMonthlyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Monthly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to validate the Milestone type in invoice$/, function (callback) {
		taskMgmtPage.verifyDateBasedMilestoneBilling().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Date Based Milestone in Milestone billing$/, function (callback) {
		taskMgmtPage.validateDateBasedMilestone(callback);
	});

	this.Then(/^I can able to delete created rows in Milestone billing$/, function (callback) {
		taskMgmtPage.validateMilestoneBillingWidgetDelectRow(callback);
	});

	this.Then(/^I can able to click on Forcast tab$/, function (callback) {
		taskMgmtPage.forcastTab().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to get Cumilative FFH text in Forcast tab$/, function (callback) {
		taskMgmtPage.forcastFFHAmountTxt().then(function(){
				callback();
		});
	});

	this.Then(/^I can able to select Terms and conditions and Operations based Milestone billings in Milestone billing$/, function (callback) {
		taskMgmtPage.validateOpsBasedMilestone(callback);
	});

	this.Then(/^I can able to validate the Ops data Milestone type invoice$/, function (callback) {
		taskMgmtPage.verifyOpsBasedMilestoneBilling().then(function(){
				callback();
		});
	});

//Monetization Module 

this.Then(/^I can able to search with Contract id in My Contacts section (.*)$/, function (contractId,callback) {
	myFleetPage.myContactsSearchOptn(contractId).then(function () {
		callback();
	});
});

this.Then(/^I can able to Validate Monetized Fixed Billing adding of rows through Add Rows modal dialog$/, function(callback) {
	myFleetPage.validateAddrowFixedBilling(callback);
});


this.Then(/^I can able to Validate Monetized Fixed Billing Delete button$/, function(callback) {
	myFleetPage.validateFixedDeleteBtn(callback);
});

this.Then(/^I can able to Validate Monetized Fixed Billing Edit button$/, function (callback) {
	myFleetPage.validateFixedEditBtn().then(function(){
			callback();
	});
});

this.Then(/^I can able to Commit Contract Terms and Conditions button$/, function (callback) {
	myFleetPage.myContactsCommitBtn().then(function(){
			callback();
	});
});

this.Then(/^I can able to Validate Monetized Variable Billing adding of rows through Add Rows modal dialog$/, function(callback) {
	myFleetPage.validateAddrowVariableMonetizationBilling(callback);
});

this.Then(/^I can able to Validate Monetized Data based Milestone Billing adding of rows through Add Rows modal dialog$/, function(callback) {
	myFleetPage.validateAddrowMilestoneMonetizationBilling(callback);
});

this.Then(/^I can able to click on Monetization Tab$/, function(callback) {
	myFleetPage.monetizationTab().then(function () {
					 callback();
	});
});

this.Then(/^I can able to wait for Monetization Tab$/, function(callback) {
	myFleetPage.waitFormonetizationTab().then(function () {
					 callback();
	});
});

this.Then(/^I can able to validate Monetization ContractId Label$/, function(callback) {
	myFleetPage.monetizationContractIDLbl().then(function (value) {
	//assert.equal(value, 'Contract ID:  ');
	console.log("Contract ID Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization ContractId$/, function(callback) {
	myFleetPage.monetizationContractID().then(function (value) {
	//assert.equal(value, 'Contract ID:  ');
	console.log("Contract ID: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization ModelId Label$/, function(callback) {
	myFleetPage.monetizationModelIDLbl().then(function (value) {
	console.log("Model ID Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization ModelId$/, function(callback) {
	myFleetPage.monetizationModelID().then(function (value) {
	console.log("Model ID: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Customer Name Label$/, function(callback) {
	myFleetPage.monetizationCustomerNameLbl().then(function (value) {
	console.log("Customer Name Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Customer Name$/, function(callback) {
	myFleetPage.monetizationCustName().then(function (value) {
	console.log("Customer Name: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Site Name Label$/, function(callback) {
	myFleetPage.monetizationSiteNameLbl().then(function (value) {
	console.log("Site Name Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Site Name$/, function(callback) {
	myFleetPage.monetizationSiteName().then(function (value) {
	console.log("Site Name: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Billing Type option Label$/, function(callback) {
	myFleetPage.monetizationBillingTypeOption().then(function (value) {
	assert.equal(value, 'Billing Type');
	console.log("Billing Type Option Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to validate Monetization Project Id option Label$/, function(callback) {
	myFleetPage.monetizationPeriodEventOption().then(function (value) {
	assert.equal(value, 'Period/Event');
	console.log("Period/Event Option Label: "+ value);
		callback();
	});
});
this.Then(/^I can able to validate Monetization Invoice Date option Label$/, function(callback) {
	myFleetPage.monetizationInvoiceDateOption().then(function (value) {
	assert.equal(value, 'Invoice Date');
	console.log("Invoice Date Option Label: "+ value);
		callback();
	});
});

this.Then(/^I can validate Billing calculation Details of Non-monetized components for Fixed billing$/, function (callback) {
	taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function(){
			callback();
	});
});

this.Then(/^I can validate Billing calculation Details of Non-monetized components for Variable billing$/, function (callback) {
	taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function(){
			callback();
	});
});

this.Then(/^I can validate Billing calculation Details of Non-monetized components for Milestone billing$/, function (callback) {
	taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function(){
			callback();
	});
});

this.Then(/^I can validate Billing Monetized MANL number for Fixed billing$/, function (callback) {
	myFleetPage.monetizationMANLNumber().then(function(){
			callback();
	});
});
this.Then(/^I can validate Billing Monetized MANL number for Variable billing$/, function (callback) {
	myFleetPage.monetizationMANLNumber().then(function(){
			callback();
	});
});
this.Then(/^I can validate Billing Monetized MANL number for Milestone billing$/, function (callback) {
	myFleetPage.monetizationMANLNumber().then(function(){
			callback();
	});
});

this.Then(/^I can able to validate Monetization Monetized Amount option Label$/, function(callback) {
	myFleetPage.monetizationMonetizedAmountOption().then(function (value) {
	assert.equal(value, 'Monetized Amount');
	console.log("Monetized Amount Option Label: "+ value);
		callback();
	});
});
this.Then(/^I can able to validate Monetization Payment Terms option Label$/, function(callback) {
	myFleetPage.monetizationPaymentTermsOption().then(function (value) {
	assert.equal(value, 'Payment Terms');
	console.log("Payment Terms Option Label: "+ value);
		callback();
	});
});
this.Then(/^I can able to validate Monetization Alpha Provisional Invoice option Label$/, function(callback) {
	myFleetPage.monetizationAlphaProvisionalInvoiceOption().then(function (value) {
	assert.equal(value, 'Alpha Provisional Invoice#');
	console.log("Alpha Provisional Invoice Option Label: "+ value);
		callback();
	});
});
this.Then(/^I can able to validate Monetization Billing Status option Label$/, function(callback) {
	myFleetPage.monetizationBillingStatusOption().then(function (value) {
	assert.equal(value, 'Billing Status');
	console.log("Billing Status Option Label: "+ value);
		callback();
	});
});

this.Then(/^I can able to Validate Monetization Dashboard data$/, function(callback) {
	myFleetPage.monetizationDataValidation(callback);
});

this.Then(/^I can able to Click on Back to Billing button$/, function(callback) {
	myFleetPage.monetizationBillingBackBtn().then(function () {
					 callback();
	});
});

this.Then(/^I can able to Validate Monetized Fixed and Variable Billing adding of rows through Add Rows modal dialog$/, function(callback) {
	myFleetPage.validateAddrowFixedAndVariableMonetizationBilling(callback);
});



		
	

		

	
};
