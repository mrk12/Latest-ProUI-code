(function() {
    'use strict';

    var currentPage = 'taskMgmtPage';
var periodEventDate;
var billingInvoiceDate;
var billingEventPeriodMonth;
var currentDate;
var billingInvoiceAmount;
var invoiceTotalAmount;
var invoiceUnitId;
var invoiceUnitIds;
var equipmentId1;
var equipmentId2;
var projectId1;
var projectId2;
var multiProjectId1;
var multiProjectId2;
var CumilativeFFHTxt;

    var TaskMgmtPage = function() {

        return {
            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            setName: function (username) {
                return cem.findElement(currentPage,'username').sendKeys(username);
            },
            setPassword: function (password) {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'password').sendKeys(password);
            },
            clickLogin: function () {
                return cem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },
            getLogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl);
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
            },

			waitForAssetsTab: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(11000);
			 return TestHelper.isElementPresent(currentPage,'assetsTab');
            },

            assetsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'assetsTab').click();
            },
            setName1: function (username) {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'loginUsername').sendKeys(username);
            },
            clickLogin1: function () {
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'loginUsername').sendKeys(protractor.Key.ENTER);
            },

            /*getLogin1: function () {
                //browser.waitForAngular();
                browser.driver.sleep(9000);
                return browser.driver.get('http://10.42.176.174:8090/myfleet4/index');
            },
                      enterSSO: function () {
                //browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'loginUsername').sendKeys('503114663');
            },

            loginButton: function () {
                //browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'loginButton').click();
            },*/

            casesTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'casesTab').click();
            },

            casesHeaderTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'casesHeaderTxt').getText();
            },

            waitForBillingTab: function() {
                browser.waitForAngular();
                browser.driver.sleep(11000);
            return TestHelper.isElementPresent(currentPage,'billingTab');
           },

            billingTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(18000);
                //browser.driver.navigate().refresh();
                //browser.driver.sleep(9000);                 
                return cem.findElement(currentPage,'billingTab').click();
            },

            billingHeaderTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'billingHeaderTxt').getText();
            },

            userNameTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'userNameTxt').click();
            },

            mySetting: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage,'setting').click();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'mySetting').click();
            },

            mySitesSearchKey: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                browser.driver.navigate().refresh();                
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'mySitesSearchKey').sendKeys('CITY PUBLIC SERVICE');
            },
            
            siteModuleSel: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                element(by.xpath("//*[@id='mysitesTreeViewBody']/ul/li[731]/input")).isSelected().then(function (value) {
                    console.log("Is site module get selected ? :" +value);
                    browser.sleep(5000);
                if(value == false){
                    return element(by.xpath("//*[@id='mysitesTreeViewBody']/ul/li[731]/input")).click();   
                    }
                    callback();
                });
                callback();
            },

            mySitesApplyBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'mySitesApplyBtn').click();
            },

            mySitesAddConformationMsg: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'mySitesAddConformationMsg').getText();
            },

            tccViewandEditBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'tccViewandEditBtn').click();
            },

            termsAndCondtionpageHeader: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'termsAndCondtionpageHeader').getText();
            },

            createNewVersionBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'createNewVersionBtn').click();
            },

            createVersionDesc: function () {
                browser.waitForAngular();
                browser.driver.sleep(7000);
                cem.findElement(currentPage,'createVersionDesc').clear();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'createVersionDesc').sendKeys('Radha Test');
            },
            /*createNewVersionCommitBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'createNewVersionCommitBtn').click();
            },*/

            /*waitFormyContactsSearchFld: function() {
                browser.waitForAngular();
                browser.driver.sleep(11000);
            return TestHelper.isElementPresent(currentPage,'myContactsSearchFld');
            },*/

            myContactsSearchFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                TestHelper.isElementPresent(currentPage,'myContactsSearchFld');
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'myContactsSearchFld').sendKeys('CS25624');
            },

            myMultiProjectContactSearchFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                TestHelper.isElementPresent(currentPage,'myContactsSearchFld');
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'myContactsSearchFld').sendKeys('CS25624');
            },
            
            forcastTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                TestHelper.isElementPresent(currentPage,'forcastTab');
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'forcastTab').click();
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'forcastSearchOption').sendKeys('CS25624');
                browser.driver.sleep(6000);
                cem.findElement(currentPage,'forcastViewEditBtn').click();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'forcast1stSiteBtn').click();
            },
            forcastFFHAmountTxt: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'forcastCumilativeFFHTxt').getText().then(function (value) {
                console.log("Cumilative FFH Txt: "+ value);
                    CumilativeFFHTxt = value;
                });

            },

            validateNoRecord:function (callback) {
                browser.waitForAngular();
                browser.sleep(9000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);

                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');
                            //cem.findElement(currentPage,'createVersionDesc').sendKeys('Test');
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[1]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='16-SELECT']/option[1]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            callback();
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[1]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='16-SELECT']/option[1]")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(4000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(8000);
                        callback();
                               });
                            });
                        });
                    }
                });
            },

            billingCommitBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingCommitBtn').click();
            },
            billingConformationCommitBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(10000);
                return cem.findElement(currentPage,'billingConformationCommitBtn').click();
            },
            billingConformationCommitTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);
                return cem.findElement(currentPage,'billingConformationCommitTxt').getText();
            },

            billingbackbtnheader: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingbackbtnheader').click();
            },

            billingScheduleHeaderTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                return cem.findElement(currentPage,'billingScheduleHeaderTxt').getText();
            },

            billingScheduleFromDateCalenarIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarIcon').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYrBackBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarDate').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys('CS25624');
            },

            billingScheduleToDateCalenarIcon: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                cem.findElement(currentPage,'billingScheduleToDateCalenarIcon').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleToDateCalenarMonth').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleToDateCalenarMonthIcon').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'billingScheduleToDateCalenar').click();               
            },

            billingScheduleFromDateCalenarIconForFixed: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarIcon').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYrBackBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarDate').click();
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys('CS25624 Fixed');
            },
            createActionTitle: function (actionTitle) {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,"billingScheduleSearchFld").sendKeys(actionTitle);
            },
            createActionTitle1: function (actionTitle1) {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,"billingScheduleSearchFld").sendKeys(actionTitle1);
            },

            createActionTitle2: function (actionTitle2) {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,"billingScheduleSearchFld").sendKeys(actionTitle2);
            },
            createActionTitle3: function (actionTitle3) {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,"billingScheduleSearchFld").sendKeys(actionTitle3);
            },

            billingScheduleSearchFldClear: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,"billingScheduleSearchFld").clear();
            },
            billingScheduleFromDateCalenar: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarIcon').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYrBackBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'billingScheduleFromDateCalenarDate').click();                
            },
            billingScheduleFromDateCalenarIconForMilestone: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                TestHelper.isElementPresent(currentPage,'billingScheduleSearchFld');
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys('CS25624 Milestone');
            },

            billingScheduleFromDateCalenarIconForMultiProjectID: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarIcon').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYrBackBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'billingScheduleFromDateCalenarDate').click();
                //browser.driver.sleep(5000);
                //return cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys('CS25624');
            },

            billingScheduleDateCalenarSet: function () {
                browser.waitForAngular();
                browser.driver.sleep(13000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarIcon').click();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarYrFrontBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'billingScheduleFromDateCalenarFrontDateBtn').click();
            },

            billingScheduleFilterApplyBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'billingScheduleFilterApplyBtn').click();
            },

            billingSchedulePeriodEventTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingSchedulePeriodEventTxt').getText();
            },
            billingConformationCommitMessage: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingConformationCommitMessage').getText();
            },

            waitForbillingConformationCommitMessage: function () {
                browser.waitForAngular();
                browser.driver.sleep(5000);
                return TestHelper.isElementPresent(currentPage, 'billingConformationCommitMessage');
            },      

            billingScheduleRecordsCount: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(15000);
                element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr/td[1]/span")).count().then(function(levelOneCount){
                console.log("Total number of Elements: "+ JSON.stringify(levelOneCount));
                browser.sleep(3000);
                for (var i=1; i<=levelOneCount; i++){
                    browser.waitForAngular();
                    browser.driver.sleep(2000);
                    console.log("Entered into for loop " +i);
                    //element.all(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                    var text = element(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[1]/span")).getText();
                    //console.log(text);
                    //text.getText().then(function(oneElementName){
                        //browser.sleep(6000);
                       console.log("Records details1: " + text);
                       //console.log("Records details2: " + text.fixed());
                    //});
                    //console.log(text);
                    }
                    callback(); 
               });
               
            },

            validateContractLevel:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            //2.1--Contract level
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000); 
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();//to.eventually.be.equals('true');
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-256-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(6000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(5000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                            browser.sleep(5000);*/
                            browser.sleep(6000); 
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-605-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            //2.1--Contract level
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();//to.eventually.be.equals('true');
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-256-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(6000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(5000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                            browser.sleep(5000);*/
                            browser.sleep(6000); 
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-605-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleFilterSearchFld: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'billingScheduleFilterSearchFld').sendKeys('Q1-2018');
            },      

            billingScheduleCalculateBtn:function () {
                browser.sleep(14000);
                return cem.findElement(currentPage,'billingScheduleCalculateBtn').isPresent().then(function(present){
                     console.log("Is any Calculate button present : " +present);
                     if(present===true){
                         cem.findElement(currentPage,'billingScheduleCalculateBtn').click();
                         browser.sleep(9000);
                         return cem.findElement(currentPage,'billingScheduleCalculateConfOkBtn').click();
                     }else{

                        return element(by.xpath("(//*[@id='Review'])[1]")).click();                                          
                     }
                 });
             },

            // billingScheduleCalculateBtn: function () {
            //     browser.waitForAngular();
            //     browser.driver.sleep(9000);
            //     return cem.findElement(currentPage,'billingScheduleCalculateBtn').click();
            // },

            billingScheduleCalculateConfChkBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'billingScheduleCalculateConfChkBtn').click();
            },

            billingScheduleCalculateConfOkBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                return cem.findElement(currentPage,'billingScheduleCalculateConfOkBtn').click();
            },
            billingScheduleCalculateUnitSnTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingScheduleCalculateUnitSnTxt').getText();
            },

            billingScheduleCalculateUnitSnValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingScheduleCalculateUnitSnValue').getText();
            },

            billingScheduleCalculatePeriodTxt: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingScheduleCalculatePeriodTxt').getText();
            },
            billingScheduleCalculatePeriodValue: function () {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                return cem.findElement(currentPage,'billingScheduleCalculatePeriodValue').getText();
            },

            billingScheduleCalculateBackBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(9000);
                cem.findElement(currentPage,'backCalculatorBtn').click();
                browser.driver.sleep(7000);
                cem.findElement(currentPage,'invoiceOutputChkBox').click();
                browser.driver.sleep(7000);
                return cem.findElement(currentPage,'confirmInvoiceReasonBtn').click();
            },

            validateIndividualRecords:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-2-RADIO']")).click();//to.eventually.be.equals('true');
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('300');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            callback();
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='1-2-RADIO']")).click();//.to.eventually.eql('true');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[1]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='16-SELECT']/option[1]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('300');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);                    
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(8000);
                        callback();
                               });
                            });
                        });
                    }
                });
            },

            validateInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            //Monthly radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-4-RADIO']")).click();
                        browser.sleep(8000);
                        //console.log('radha');
                        TestHelper.elementToBeSelected(currentPage, 'monthly');
                        browser.sleep(8000);
                        TestHelper.elementToBeClickable(currentPage, 'quarterly');                                
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000); 
                        TestHelper.elementToBeClickable(currentPage, 'annually');                           
                        browser.sleep(5000);
                        //Quarterly radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeSelected(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeClickable(currentPage, 'annually'); 
                        browser.sleep(5000);
                        //Semi Anually radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-6-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeClickable(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeSelected(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeClickable(currentPage, 'annually'); 
                        browser.sleep(5000);
                        //Anually radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-7-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeClickable(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeSelected(currentPage, 'annually');
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(5000);                             
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        //Monthly radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-4-RADIO']")).click();
                        browser.sleep(8000);
                        //console.log('radha');
                      TestHelper.elementToBeSelected(currentPage, 'monthly');
                        browser.sleep(8000);
                       TestHelper.elementToBeClickable(currentPage, 'quarterly');                                
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000); 
                        TestHelper.elementToBeClickable(currentPage, 'annually');                           
                        browser.sleep(5000);
                        //Quarterly radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeSelected(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeClickable(currentPage, 'annually'); 
                        browser.sleep(5000);
                        //Semi Anually radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-6-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeClickable(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeSelected(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeClickable(currentPage, 'annually'); 
                        browser.sleep(5000);
                        //Anually radio button selection in 2.2 section
                        element(by.xpath("//*[@id='2-7-RADIO']")).click();
                        browser.sleep(5000);
                        TestHelper.elementToBeClickable(currentPage, 'monthly');
                        browser.sleep(6000);
                        TestHelper.elementToBeClickable(currentPage, 'quarterly'); 
                        browser.sleep(3000);
                        TestHelper.elementToBeClickable(currentPage, 'semiAnnually');
                        browser.sleep(4000);                            
                        TestHelper.elementToBeSelected(currentPage, 'annually');
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(5000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();                                
                               });
                            });
                        });
                    }
                });
            },

            validateMonthlyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                       // });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(5000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                               });
                            });
                        });
                    }
                });
            },

   
            billingScheduleEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'billingScheduleEventPeriodTxt').getText().then(function (value) {
                    console.log("Current periodEvent Date: "+ value.toLowerCase());
                    periodEventDate = value.toLowerCase();
                });

            },

            verifyMonthlyFrequencyCurrentDate: function () {
                browser.driver.sleep(8000);
                  return cem.findElement(currentPage,'billingScheduleCalculateTypeValue').getText().then(function (periodDate) {
                    var res = periodDate.toLowerCase();
                    console.log("Current Date: "+ res);
                    console.log("Frequency Date : "+ periodEventDate);                 
                    return assert.equal(periodEventDate, res); 
                    //return assert.isTrue(periodEventDate, res);                   
                });

            },
            storeSite:function () {
                return cem.findElement(currentPage,'billingScheduleEventPeriodTxt').getText().then(function(storeSite){
                    currentDate = storeSite.toLowerCase();
                    console.log("Value of current Date is:" +currentDate);
                });
            },

            /*verifyMonthlyFrequencyCurrentDate12:function () {
                browser.sleep(3000);
                console.log("Stored date is : " + currentDate);
             return  element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (displaySite) {
                    console.log("Display Dates are : " +displaySite.toString().toLowerCase());
                    if(displaySite.toString().toLowerCase().includes(currentDate)){
                        console.log("Date is Present");
                    }else{
                        console.log("Date is not Present");
                    }

                });

            },*/

            verifyMonthlyFrequencyCurrentDate12: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
               element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("Quarter Period: "+ value);                   
                    });  
                });
            },

            validateQuarterlyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    }else{
                                        console.log("Selected Specified day of the month");
                                    } 
                           /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            browser.sleep(4000);                       
                            element(by.xpath("//*[@id='93-256-RADIO']")).click();
                            browser.sleep(4000);
                            //2.8--No
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);                        
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(4000); 
                            //2.11 Yes
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    }else{
                                        console.log("Selected Specified day of the month");
                                    } 
                           /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            browser.sleep(4000);                       
                            element(by.xpath("//*[@id='93-256-RADIO']")).click();
                            browser.sleep(4000);
                            //2.8--No
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);                        
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(4000); 
                            //2.11 Yes
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                });
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleQuarterlyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
               element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("2nd periodEvent Date: "+ value);
                        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
                            console.log("3rd periodEvent Date: "+ value);
                            });
                        });    
                    });  
                });
            },

            validateSemiannuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                       // });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleSemiannuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("2nd periodEvent Date: "+ value);
                        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
                            console.log("3rd periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
                            console.log("4th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[19]")).getText().then(function (value) {
                            console.log("5th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[23]")).getText().then(function (value) {
                            console.log("6th periodEvent Date: "+ value);
                                        });
                                    });
                                });
                            });
                        });    
                    });  
                });

            },

            validateAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                           /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("2nd periodEvent Date: "+ value);
                        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
                            console.log("3rd periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
                            console.log("4th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[19]")).getText().then(function (value) {
                            console.log("5th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[23]")).getText().then(function (value) {
                            console.log("6th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[27]")).getText().then(function (value) {
                            console.log("7th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[31]")).getText().then(function (value) {
                            console.log("8th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[35]")).getText().then(function (value) {
                            console.log("9th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[39]")).getText().then(function (value) {
                            console.log("10th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[43]")).getText().then(function (value) {
                            console.log("11th periodEvent Date: "+ value);
                            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[47]")).getText().then(function (value) {
                            console.log("12th periodEvent Date: "+ value);
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });    
                    });  
                });

            },
            validateQuarterlyQuarterlyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                       // });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                               });
                            });
                        });
                    }
                });
            },

            validateQuarterlySemiAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleQuarterlySemiAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st Quarter periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("2nd Quarter periodEvent Date: "+ value); 
            });                           
                        });    
                    });                
            },

            validateQuarterlyAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                   // });
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleQuarterlyAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st Quarter periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("2nd Quarter periodEvent Date: "+ value);
                        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
                        console.log("3rd Quarter periodEvent Date: "+ value);
                        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
                        console.log("4th Quarter periodEvent Date: "+ value);
                    });                            
                                });                             
                            });                             
                        });    
                    });                
            },

            validateSemiAnnuallySemiAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi-Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleSemiAnnuallySemiAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("Single Half-year  periodEvent Date: "+ value);
                        });
                    });                
            },

            validateSemiAnnuallyAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleSemiAnnuallyAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("1st Half-year  periodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                    console.log("2nd Half-year  periodEvent Date: "+ value); 
            });                      
                        });   
                    });                
            },

            validateAnnuallyAnnuallyInvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleAnnuallyAnnuallyEventPeriodTxt: function () {
                browser.driver.sleep(5000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("Calculation of year periodEvent Date: "+ value);
                    //element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                    //console.log("2nd Half-year  periodEvent Date: "+ value);                       
                       });   
                    });                
            },

            validateMonthlyActualDate30InvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleInvoiceTxt: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'billingScheduleInvoiceTxt').getText().then(function (value) {
                var d = new Date(value);
                 var datestring = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear(); 
                console.log("Current Invoice Date: "+ datestring);
                    //console.log("Current Invoice Date: "+ value);
                    billingInvoiceDate = datestring;
                });

            },

            verifyMonthlyFrequencyEntitlementDate: function () {
                browser.driver.sleep(8000);
                  return cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
                    var d = new Date(periodDate);
                 var datestring1 = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear(); 
                console.log("Current Entitlement Date: "+ datestring1);                 
                    return assert.equal(billingInvoiceDate, datestring1); 
                    //return assert.isTrue(periodEventDate, res);                   
                });

            },

            validateMonthlyActualDate31InvoiceFrequency:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateMonthlyInvoiceFrequencyCurrentWithinBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-20-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='5-20-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            billingScheduleInvoiceMonthTxt: function () {
                browser.driver.sleep(5000);
                return cem.findElement(currentPage,'billingScheduleCalculateTypeValue').getText().then(function (value) {
                    var dt = new Date(value);
                    //var text = dt.split(new RegExp('-'));
                    //var month = console.log(text[0]);
                    dt.setMonth( dt.getMonth());
                     console.log( dt );
                     var txt = dt.toString().split(new RegExp(' '));
                   var month = console.log(txt[1]);
                   console.log(month);
                    billingEventPeriodMonth = month;
                });

            },
            verifyMonthlyFrequencyEntitlementMonth1: function () {
                browser.driver.sleep(8000);
                  return cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
                    var dt = new Date(periodDate);
                    //var dt = new Date("28-Nov-2018");
                    dt.setMonth( dt.getMonth() - 1);
                    console.log( dt );
             var monthstring = dt.toString().split(new RegExp(' '));
                 var entitledMonth = console.log(monthstring[1]);
                 //console.log(entitledMonth);                
                    return assert.equal(billingEventPeriodMonth, entitledMonth); 
                    //return assert.isTrue(periodEventDate, res);                   
                });

            },

            verifyMonthlyFrequencyEntitlementMonth: function () {
                browser.driver.sleep(8000);
                  return cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
                    var dt = new Date(periodDate);
                    //var dt = new Date("28-Nov-2018");
                    dt.setMonth( dt.getMonth() - 2);
                    console.log( dt );
             var monthstring = dt.toString().split(new RegExp(' '));
                 var entitledMonth = console.log(monthstring[1]);
                 //console.log(entitledMonth);                
                    return assert.equal(billingEventPeriodMonth, entitledMonth); 
                    //return assert.isTrue(periodEventDate, res);                   
                });

            },
            verifyMonthlyFrequencyEntitlementCurrentMonth: function () {
                browser.driver.sleep(8000);
                  return cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
                    var dt = new Date(periodDate);
                    //var dt = new Date("28-Nov-2018");
                    dt.setMonth( dt.getMonth());
                    console.log( dt );
             var monthstring = dt.toString().split(new RegExp(' '));
                 var entitledMonth = console.log(monthstring[1]);
                 //console.log(entitledMonth);                
                    return assert.equal(billingEventPeriodMonth, entitledMonth); 
                });

            },
            validateMonthlyInvoiceFrequencyNoEstimationRequired:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            //Within (Prior to end of billing period)/ No estimation required
                            element(by.xpath("//*[@id='5-320-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(6000);
                            //Within (Prior to end of billing period)/ No estimation required
                            element(by.xpath("//*[@id='5-320-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Current billing month (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateQuarterlyInvoiceFrequencyAfterBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateQuarterlyInvoiceFrequencyAfterBilling2ndMonth:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateQuarterlyInvoiceFrequencyWithinBilling1stMonth:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //Within (Prior to end of billing period)/ Estimation required
                            element(by.xpath("//*[@id='5-20-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='-1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //Within (Prior to end of billing period)/ Estimation required
                            element(by.xpath("//*[@id='5-20-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='-1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            verifyQuarterlyFrequencyEntitlementMonth: function () {
                browser.driver.sleep(8000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                  cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
                    var d = new Date(periodDate);
                    var periodDt = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear(); 
             console.log("Entitled Month :", periodDt);
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("PeriodEvent Date: "+ value);
                    return assert.equal(billingInvoiceDate, periodDt);                       
                       });            
                });
            });
            },

            verifyQuarterlyFrequencyEntitlementMonthDeviation1: function () {
                browser.driver.sleep(8000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                  cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
             console.log("Entitled Month :", periodDate);
             var d = new Date(periodDate);
                    var periodDt = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear(); 
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("PeriodEvent Date: "+ value);
                    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                        console.log("PeriodEvent Date: "+ value);
                    return assert.equal(periodDt, billingInvoiceDate); 
                        });                       
                    });            
                });
            });
            },

            validateQuarterlyInvoiceFrequencyWithinBilling2ndtMonth:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                            //Within (Prior to end of billing period)/ No estimation required
                            element(by.xpath("//*[@id='5-320-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='4-SELECT']/option[text()='-1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd month of the quarter(within billing period)']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month of the quarter(within billing period)']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.2 section
                            element(by.xpath("//*[@id='2-5-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(6000);
                           //Within (Prior to end of billing period)/ No estimation required
                           element(by.xpath("//*[@id='5-320-RADIO']")).click();
                           browser.sleep(6000);
                           element(by.xpath("//*[@id='4-SELECT']/option[text()='-1']")).click();
                           browser.sleep(6000);                            
                           element(by.xpath("//*[@id='12-SELECT']/option[text()='31st']")).click();
                           browser.sleep(6000);
                           element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd month of the quarter(within billing period)']")).click();
                           browser.sleep(5000);
                           element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month of the quarter(within billing period)']")).click();
                           browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateSemiAnnuallyInvoiceFrequencyWithinBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            //element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            //browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            //element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            //browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateSemiAnnuallyInvoiceFrequencyDeviation0After:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            //element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            //browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            //element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            //browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth30th:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='1']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.2 section
                            element(by.xpath("//*[@id='2-6-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Semi Annually from 2.3 section
                            element(by.xpath("//*[@id='3-10-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='222-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },
            
            validateAnnuallyInvoiceFrequencyAfterBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            validateAnnuallyInvoiceFrequency30thAfterBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                        //});
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Annually from 2.2 section
                            element(by.xpath("//*[@id='2-7-RADIO']")).click();
                            browser.sleep(6000);
                            //Selecting Annually from 2.3 section
                            element(by.xpath("//*[@id='3-11-RADIO']")).click();
                            browser.sleep(6000);
                            //After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                            browser.sleep(6000);                            
                            element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(5000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(6000);                        
                            element(by.xpath("//*[@id='commit']")).click().then(function () {
                            browser.sleep(5000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback();
                                    //});
                               });
                            });
                        });
                    }
                });
            },

            verifyAnnuallyFrequencyEntitlementMonth: function () {
                browser.driver.sleep(8000);
                return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                    console.log("Billing for Period Header Txt: "+ value);
                  cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
             console.log("Entitled Month :", periodDate);
             var d = new Date(periodDate);
                 var dates = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear();
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                    console.log("PeriodEvent Date: "+ value);
                    return assert.equal(dates, billingInvoiceDate);                       
                       });               
                    
                });

            });

        },

        verifyAnnuallyFrequencyEntitlementMonth30th: function () {
            browser.driver.sleep(8000);
            return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                console.log("Billing for Period Header Txt: "+ value);
              cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
         console.log("Entitled Month :", periodDate);
         var d = new Date(periodDate);
                 var date1 = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear();
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                console.log("PeriodEvent Date: "+ value);
                return assert.equal(date1, billingInvoiceDate);                       
                   });               
                
            });

        });

    },

        validateAnnuallyInvoiceFrequencyAfterBilling2ndMonth:function (callback) {
            browser.waitForAngular();
            browser.sleep(12000);
            element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                console.log(value);
                if(value == true || value == "true"){
                    browser.sleep(5000); 
                    element(by.xpath("//*[@id='createnewversion']")).isPresent();
                    //console.log("test123");
                    element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(6000);
                        //Selecting Annually from 2.2 section
                        element(by.xpath("//*[@id='2-7-RADIO']")).click();
                        browser.sleep(6000);
                        //Selecting Annually from 2.3 section
                        element(by.xpath("//*[@id='3-11-RADIO']")).click();
                        browser.sleep(6000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                        browser.sleep(6000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                        browser.sleep(5000);
                        /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }                                                        
                        browser.sleep(4000);*/
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='33-129-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-188-chkbox']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                    //});
                                });
                            });
                        });
                     });
                }else{
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).isPresent();
                    element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(6000);
                        //Selecting Annually from 2.2 section
                        element(by.xpath("//*[@id='2-7-RADIO']")).click();
                        browser.sleep(6000);
                        //Selecting Annually from 2.3 section
                        element(by.xpath("//*[@id='3-11-RADIO']")).click();
                        browser.sleep(6000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='233-SELECT']/option[text()='0']")).click();
                        browser.sleep(6000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='25th']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd Month post billing period close']")).click();
                        browser.sleep(5000);
                        /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }                                                        
                        browser.sleep(4000);*/
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='33-129-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-188-chkbox']")).click();
                        browser.sleep(6000);                        
                        element(by.xpath("//*[@id='commit']")).click().then(function () {
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                //});
                           });
                        });
                    });
                }
            });
        },

        verifyAnnuallyFrequencyEntitlement2ndMonth: function () {
            browser.driver.sleep(8000);
            return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
                console.log("Billing for Period Header Txt: "+ value);
              cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
         console.log("Entitled Month :", periodDate);
         var d = new Date(value);
                 var dates = d.getDate()  + "-" + (d.getMonth()+1) + "-" + d.getFullYear();
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
                console.log("PeriodEvent Date: "+ value);
                return assert.equal(dates, billingInvoiceDate);                       
                   });               
                
            });

        });
    },

    verifyMyContractsTitle: function () {
        browser.sleep(9000);
        return TestHelper.isElementPresent(currentPage, "myContractsTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsTitle");
            return element.getText();
        });
    },

    verifyBillingScheduleTitle: function () {
        browser.sleep(5000);
        return TestHelper.isElementPresent(currentPage, "billingScheduleTitle").then(function(){
            var element = cem.findElement(currentPage, "billingScheduleTitle");
            return element.getText();
        });
    },

    verifyOutageScheduleTitle: function () {
        browser.sleep(5000);
        return TestHelper.isElementPresent(currentPage, "outageScheduleTitle").then(function(){
            var element = cem.findElement(currentPage, "outageScheduleTitle");
            return element.getText();
        });
    },

    verifyMyContractsCustomersTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsCustomersTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsCustomersTitle");
            return element.getText();
        });
    },

    verifyMyContractsContractTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsContractTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsContractTitle");
            return element.getText();
        });
    },

    verifyMyContractsModelIDTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsModelIDTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsModelIDTitle");
            return element.getText();
        });
    },

    verifyMyContractsSiteTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsSiteTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsSiteTitle");
            return element.getText();
        });
    },    

    verifyMyContractsStatusTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsStatusTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsStatusTitle");
            return element.getText();
        });
    },

    verifyMyContractsOpDataTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsOpDataTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsOpDataTitle");
            return element.getText();
        });
    },
    verifyMyContractsTandCsTitle: function () {
        browser.sleep(3000);
        return TestHelper.isElementPresent(currentPage, "myContractsTandCsTitle").then(function(){
            var element = cem.findElement(currentPage, "myContractsTandCsTitle");
            return element.getText();
        });
    },

    validateQuarterlyBillingEscalationForSameRate:function (callback) {
        browser.waitForAngular();
        browser.sleep(12000);
        element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
            console.log(value);
            if(value == true || value == "true"){
                browser.sleep(5000); 
                element(by.xpath("//*[@id='createnewversion']")).isPresent();
                //console.log("test123");
                element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                    browser.sleep(3000);
                    element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                    browser.sleep(10000);
                    element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                    browser.sleep(6000);
                    //Selecting Quarterly from 2.2 section
                    element(by.xpath("//*[@id='2-5-RADIO']")).click();
                    browser.sleep(6000);
                    //Selecting Quarterly from 2.3 section
                    element(by.xpath("//*[@id='3-9-RADIO']")).click();
                    browser.sleep(6000);
                    //After (After end of billing period)
                    element(by.xpath("//*[@id='5-19-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                    browser.sleep(6000);                            
                    element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                    browser.sleep(5000);
                    //2.7-a) Specified day of the month
                    element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                        console.log(value);
                            if(value==true ){
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).click();
                            }else{
                                console.log("Already 2.7 Specified day of the month selected ");
                            } 
                       // });
                    browser.sleep(5000);
                    //2.7 Actual day
                    element(by.xpath("//*[@id='93-256-RADIO']")).click();
                    browser.sleep(5000);                                                
                    element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                    browser.sleep(5000);
                    //2.8 No selection
                    element(by.xpath("//*[@id='19-92-RADIO']")).click();
                    browser.sleep(5000);
                    //2.9.Contract allow for billing Escalation -Yes
                    element(by.xpath("//*[@id='20-91-RADIO']")).click();
                    browser.sleep(5000);
                    //2.9.3.Different escalation rate for different type of billing -No
                    element(by.xpath("//*[@id='22-92-RADIO']")).click();
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                    browser.sleep(4000);
                    //2.9.3.3.Do you configure different Escalation rate for different period? --No
                    element(by.xpath("//*[@id='178-92-RADIO']")).click();
                    browser.sleep(4000);
                    /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                        console.log(value);
                            if(value==true ){
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='102-1-chkbox']")).click();
                            }else{
                                console.log("Not associated with Other Contract");
                            }                                                        
                    browser.sleep(4000);*/
                    element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='26-104-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                    browser.sleep(4000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                    browser.sleep(4000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='99-92-RADIO']")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='33-129-RADIO']")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='84-188-chkbox']")).click();
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).click();
                    browser.sleep(5000);
                    console.log("Please confirm to Commit");
                    element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                    browser.sleep(9000);
                    callback();
                                });
                            });
                        });
                    });
                 });
            }else{
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).isPresent();
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(6000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                    browser.sleep(6000);
                    //Selecting Quarterly from 2.2 section
                    element(by.xpath("//*[@id='2-5-RADIO']")).click();
                    browser.sleep(6000);
                    //Selecting Quarterly from 2.3 section
                    element(by.xpath("//*[@id='3-9-RADIO']")).click();
                    browser.sleep(6000);
                    //After (After end of billing period)
                    element(by.xpath("//*[@id='5-19-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                    browser.sleep(6000);                            
                    element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                    browser.sleep(5000);
                    //2.7-a) Specified day of the month
                    element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                        console.log(value);
                            if(value==true ){
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).click();
                            }else{
                                console.log("Already 2.7 Specified day of the month selected ");
                            } 
                       // });
                    browser.sleep(5000);
                    //2.7 Actual day
                    element(by.xpath("//*[@id='93-256-RADIO']")).click();
                    browser.sleep(5000);                                                
                    element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                    browser.sleep(6000);
                    element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                    browser.sleep(5000);
                    //2.8 No selection
                    element(by.xpath("//*[@id='19-92-RADIO']")).click();
                    browser.sleep(5000);
                    //2.9.Contract allow for billing Escalation -Yes
                    element(by.xpath("//*[@id='20-91-RADIO']")).click();
                    browser.sleep(5000);
                    //2.9.3.Different escalation rate for different type of billing -No
                    element(by.xpath("//*[@id='22-92-RADIO']")).click();
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                    browser.sleep(4000);
                    //2.9.3.3.Do you configure different Escalation rate for different period? --No
                    element(by.xpath("//*[@id='178-92-RADIO']")).click();
                    browser.sleep(4000);
                    /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                        console.log(value);
                            if(value==true ){
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='102-1-chkbox']")).click();
                            }else{
                                console.log("Not associated with Other Contract");
                            }                                                        
                    browser.sleep(4000);*/
                    element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='26-104-RADIO']")).click();
                    browser.sleep(6000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                    browser.sleep(4000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                    browser.sleep(4000);
                    element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='99-92-RADIO']")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='33-129-RADIO']")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='84-188-chkbox']")).click();
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).click();
                    browser.sleep(5000);
                    console.log("Please confirm to Commit");
                    element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                    browser.sleep(9000);
                    callback();
                          // });
                       });
                    });
                });
            }
        });
    },

    verifyQuarterlyFrequencyEscalationForSame: function () {
        browser.driver.sleep(8000);
        return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
            console.log("Billing for Period Header Txt: "+ value);
          cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
     console.log("Entitled Month :", periodDate);
     element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
            console.log("PeriodEvent Date: "+ value);
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
            console.log("Type: "+ value);
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
            console.log("Amount: "+ value);
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[6]")).getText().then(function (value) {
            console.log("PeriodEvent Date: "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                console.log("Type : "+ value);
                element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[9]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);
                browser.sleep(2000);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
                    return console.log("Total Amount : "+ total);
                                });
                            });
                        });
                    });
                 });                      
               });                     
            });     
        });
    });
},

verifyTotalBillableAmount: function () {
    browser.driver.sleep(5000);
    return element(by.id("totalFixedBilling")).getText().then(function (value) {
        console.log("Billing Amount Txt: "+ value);
    });
},

/*billingScheduleInvoiceAmountTxt1: function () {
    browser.driver.sleep(5000);
    return cem.findElement(currentPage,'billingScheduleTotalAmount').getText().then(function (value) {
        var amount = value.toString().split(" ").join(" ");
        var init = amount.indexOf();
        var fin = amount.indexOf('.');
var totalAmount = Number((amount.substr(init + 1,  fin - init -1))); 
console.log("Billing schedule Total Amount:" + totalAmount);  
      billingInvoiceAmount = totalAmount;
    });

},

verifyMonthlyFrequencyTotalAmountTxt1: function () {
    browser.driver.sleep(9000);
      return cem.findElement(currentPage,'billingScheduleInvoiceTotalAmount').getText().then(function (amount) {
        var value = amount.toString().split(" ").join(" ").replace(/Total :/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf('.');
 var invoiceTotalAmount = Number((value.substr(init + 1,  fin - init -1)));
        console.log("Total Amount:" + invoiceTotalAmount);                
        return assert.equal(billingInvoiceAmount, invoiceTotalAmount);               
    });

},*/

verifyMonthlyFrequencyTotalAmountTxt: function () {
    browser.driver.sleep(5000);
      return cem.findElement(currentPage,'billingScheduleInvoiceTotalAmount').getText().then(function (amount) {
        var value = amount.toString().split(" ").join(" ").replace(/Total :/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf('.');
 var totalAmounts = ((value.substr(init + 1,  fin - init -1)));
 browser.driver.sleep(4000);
        console.log("Total Amount:" + totalAmounts);                
        invoiceTotalAmount = totalAmounts;    
    });

},
waitForbillingScheduleInvoiceAmountTxt: function() {
    browser.waitForAngular();
    browser.driver.sleep(11000);
return TestHelper.isElementPresent(currentPage,'billingScheduleTotalAmount');
},

billingScheduleInvoiceAmountTxt: function () {
    browser.driver.sleep(11000);
    return cem.findElement(currentPage,'billingScheduleTotalAmount').getText().then(function (value) {
        var amount = value.toString().split(" ").join(" ");
        var init = amount.indexOf();
        var fin = amount.indexOf('.');
var totalAmount = ((amount.substr(init + 1,  fin - init -1))); 
console.log("Billing schedule Total Amount:" + totalAmount);  
      //billingInvoiceAmount = totalAmount;
      return assert.equal(invoiceTotalAmount, totalAmount);
    });
},

quarterBillingScheduleInvoiceAmountTxt: function (callback) {
    browser.waitForAngular();
    browser.driver.sleep(9000);            
  return  element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr")).count().then(function (cnt) {
    var message = "Q1-2018";
  for (var i = 1; i < cnt; i++) {
        browser.sleep(9000);
        (element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[7]")).get(count)).getText().then(function (value) {
        console.log("Text is Value : ", value, message, i);
        browser.sleep(9000);
        if(value == message ){
            browser.sleep(9000);
            console.log("Text : " + i);
          element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[8]")).getText().then(function (value) {
          browser.sleep(9000);
          var amount = value.toString().split(" ").join(" ");
        var init = amount.indexOf();
        var fin = amount.indexOf('.');
var totalAmount = ((amount.substr(init + 1,  fin - init -1))); 
console.log("Billing schedule Total Amount:" + totalAmount);  
      //billingInvoiceAmount = totalAmount;
      return assert.equal(invoiceTotalAmount, totalAmount);
        });    
            }else{
     browser.driver.sleep(4000);
                console.log("No Data Avaliable");
            }
        });
    }
   // callback();
   });
},

validateQuarterlyBillingEscalationForDifferentRate:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -Yes
                element(by.xpath("//*[@id='22-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys('.4');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys('.2');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys('.15');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys('.1');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys('.05');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='107-328-RADIO']")).click();
                browser.sleep(4000)
                element(by.xpath("//*[@id='126-419-RADIO']")).click();
                browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-187-chkbox']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                        browser.sleep(3000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button")).click();
                        browser.sleep(3000);
                        element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[5]")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -Yes
                element(by.xpath("//*[@id='22-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Fixed billings']")).sendKeys('.4');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Variable billings'])[1]")).sendKeys('.2');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Milestone billings'])[2]")).sendKeys('.15');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Bonus'])[1]")).sendKeys('.1');
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@id='LD'])[2]")).sendKeys('.05');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='126-419-RADIO']")).click();
                browser.sleep(4000)
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-187-chkbox']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button")).click();
                        browser.sleep(3000);
                        element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[5]")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                      });
                   });
                });
            });
        }
    });
},
verifyMonthlyFrequencyEscalationForDifferent: function () {
    browser.driver.sleep(8000);
    var escDes = 'VARIABLE-Escalation - 30%';
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
        console.log("Variable Amount: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (value) {
            console.log("Escalation Amount : "+ value);            
            browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[10]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[15]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
                element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[text()='VARIABLE-Escalation - 30%']")).getText().then(function (value) {
                    console.log("Escalation Description: "+ value);
                    assert.equal(value, escDes);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[14]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[20]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
            return console.log("Total Amount : "+ total);
                                        });
                                      });
                                   });
                                 });
                                });
                               });                      
                             }); 
                            });
                        });
                    });
                });
             });                      
           });                     
        });     
    });
});
},

verifyMonthlyFrequencyEscalationForDifferent1: function () {
    browser.driver.sleep(8000);
    var escDes = 'VARIABLE-Escalation - 40%';
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
        console.log("Variable Amount: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (value) {
            console.log("Escalation Amount : "+ value);            
            browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[10]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[15]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
                element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[text()='VARIABLE-Escalation - 30%']")).getText().then(function (value) {
                    console.log("Escalation Description: "+ value);
                    assert.equal(value, escDes);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[14]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[20]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
            return console.log("Total Amount : "+ total);
                                        });
                                      });
                                   });
                                 });
                                });
                               });                      
                             }); 
                            });
                        });
                    });
                });
             });                      
           });                     
        });     
    });
});
},

verifyQuarterlyFrequencyEscalationForDifferent: function () {
    browser.driver.sleep(8000);
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
        console.log("Fixed Amount: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (value) {
            console.log("Escalation Amount : "+ value);            
            browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[10]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[15]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[14]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[15]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[20]")).getText().then(function (value) {
                console.log("Escalation Amount : "+ value);            
                browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
            return console.log("Total Amount : "+ total);
                                      });
                                   });
                                 });
                                });
                               });                      
                             }); 
                            });
                        });
                    });
                });
             });                      
           });                     
        });     
    });
});
},

verifyQuarterlyFrequencyEscalationSeparateLine: function () {
    browser.driver.sleep(8000);
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
        console.log("Variable Amount: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope'][text()='ESCALATION']")).getText().then(function (value) {
            console.log("Escalation type: "+ value);            
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (value) {
            console.log("Escalation Amount : "+ value);            
            browser.sleep(2000);        
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
            return console.log("Total Amount : "+ total);  
        });
                            });
                        });
                    });
                });
             });                      
           });                     
        });     
    });
  });
},

verifyQuarterlyFrequencyFFHEscalation: function () {
    browser.driver.sleep(8000);
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 browser.driver.sleep(4000);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (value) {
        console.log("Fixed Amount: "+ value);                    
            browser.sleep(2000);        
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (total) {
            return console.log("Total Amount : "+ total);  
                            });
                        });
                    });
                });
           });                      
        });                                 
    },

        billingOpsDataViewBtn: function () {
        browser.waitForAngular();
        browser.driver.sleep(12000);
        return cem.findElement(currentPage,'billingOpsDataViewBtn').click();
        },

        billingOpsDataFromCalendarIcon: function () {
            browser.waitForAngular();
            browser.driver.sleep(17000);
            cem.findElement(currentPage,'billingOpsDataFromCalendarIcon').click();
            browser.driver.sleep(3000);
            cem.findElement(currentPage,'billingOpsDataCalendarJanBtn').click();
            browser.driver.sleep(4000);
            cem.findElement(currentPage,'billingOpsDataToCalendarIcon').click();
            browser.driver.sleep(4000);
            cem.findElement(currentPage,'billingOpsDataToCalendarFebBtn').click();
            browser.driver.sleep(4000);
            return cem.findElement(currentPage,'billingOpsDataToCalendarApplyBtn').click();
        },

        approve1stRecords:function () {
            browser.waitForAngular();
            browser.sleep(30000);
            return cem.findElement(currentPage,'billingOpsDataToCalendarApplyBtn').isPresent().then(function(){
            var text= 'Unapproved';
            browser.sleep(12000); 
            for ( var m=1; m<=3; ++m){
                console.log(m);
                browser.sleep(9000); 
            element.all(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ m +"]/td[14]")).getText().then(function(value){
                console.log(value, text, m);
                if(value == text){
                    browser.sleep(8000);
                    //for ( var n=1; n<=m; ++n){ 
                    //console.log("Radha123");
                    //element.all(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ m +"]/td[2]/a")).isPresent();
                    //var totalhour = element.all(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ m +"]/td[2]/a"));
                    //totalhour.click().then(function () {
             browser.actions().mouseMove(element(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ m +"]/td[2]/a"))).click().perform().then(function () {
                    browser.sleep(3000);
                    //element(by.xpath('//*[@title="'+action+'"]')).click();
                        browser.sleep(8000);
                        //console.log("Radha123");
                        element(by.xpath("//*[@id='hoursEditSection']/div/div[1]/label[1]")).getText().then(function (hours) {                            
                        browser.sleep(5000);
                        var value = hours.toString().split(" ").join(" ").replace(/This month has/g, "");
                        var init = value.indexOf('');
                        var fin = value.indexOf('hours');
                 var totalHours = ((value.substr(init + 1,  fin - init -1)));
                        console.log("Total No of Hours:" + totalHours);
                        browser.sleep(5000);
                        element(by.xpath("//*[@class='btn btn-info btn-lg pull-right']")).click();
                        browser.sleep(8000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).click().perform();
                        //element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        //browser.sleep(3000);
                        //element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(5000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).sendKeys(totalHours);
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='uiGrid-006Y-running']")).click().then(function () {
                        browser.sleep(3000);
                        browser.actions().doubleClick(element(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope ui-grid-cell-focus']"))).perform();
                        browser.sleep(3000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope ui-grid-cell-focus'][text()='natural gas']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='changeReasonSelect']/option[text()='Turbine Controller: totalizer error']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='buttonApprove'][text()='Approve']")).click();
                        browser.sleep(10000);                        
                         console.log("Please click on Approved");
                        //callback();
                            });
                        });                        
                     });
                    //}
                }else{
                    browser.sleep(9000);
                    //element(by.xpath("(//*[@class='ng-scope'][text()='Approved'])[1]")).isPresent().then(function () {                        
                    console.log("Already approved the selected Month");                   
                    //callback();
                    //});
                }
            });
           }
        });
           //callback(); 
        },

        /*approve1stRecords: function (callback) {
            browser.sleep(15000);         
                var elm = element(by.xpath("//*[@class='btn btn-primary datealign myfleetInputs myfleetButtons'][text()='Apply']"));
                var i;
                var text= 'Unapproved';
                TestHelper.isElementPresent(elm).then(function (hasPill) {
                    //console.log("Validation :" + hasPill);
                    if (hasPill) {
                            for (i = 0; i <= 15; i++) {
                                element.all(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ i +"]/td[14]")).getText().then(function(value){
                    console.log(value, text, i);
                    if(value == text){
                        browser.actions().mouseMove(element(by.xpath("//*[@id='hoursUCTableId']/tbody/tr["+ i +"]/td[2]/a"))).click().perform().then(function () {
                    browser.sleep(3000);
                        browser.sleep(8000);
                        console.log("Radha123");
                        element(by.xpath("//*[@id='hoursEditSection']/div/div[1]/label[1]")).getText().then(function (hours) {                            
                        browser.sleep(5000);
                        var value = hours.toString().split(" ").join(" ").replace(/This month has/g, "");
                        var init = value.indexOf('');
                        var fin = value.indexOf('hours');
                 var totalHours = ((value.substr(init + 1,  fin - init -1)));
                        console.log("Total No of Hours:" + totalHours);
                        browser.sleep(5000);
                        element(by.xpath("//*[@class='btn btn-info btn-lg pull-right']")).click();
                        browser.sleep(8000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).click().perform();
                        browser.sleep(5000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-scope ui-grid-cell-focus emptyHoursField']/input")).sendKeys(totalHours);
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='uiGrid-006Y-running']")).click().then(function () {
                        browser.sleep(3000);
                        browser.actions().doubleClick(element(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope ui-grid-cell-focus']"))).perform();
                        browser.sleep(3000);
                        element(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope ui-grid-cell-focus'][text()='natural gas']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='changeReasonSelect']/option[text()='Turbine Controller: totalizer error']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='buttonApprove'][text()='Approve']")).click();
                        browser.sleep(10000);                        
                         console.log("Please click on Approved");
                                  });
                                });
                            });
                            }else {
                                console.log("Already approved the selected Month");
                                callback();                        
                            }
                        });
                    }
            } else {
                console.log("Non of the turbine is present");
                callback();            
        }
    });
    },*/

        billingOpsBackToBillingBtn: function () {
            browser.waitForAngular();
            browser.driver.sleep(9000);
            return cem.findElement(currentPage,'billingOpsBackToBillingBtn').click();
        },

        quarterRequestAccess: function (callback) {
            browser.waitForAngular();
            browser.driver.sleep(9000);            
          return  element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr")).count().then(function (cnt) {
            var message = "Q1-2018";
          for (var i = 1; i < cnt; i++) {
                browser.sleep(9000);
                (element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[7]")).get(count)).getText().then(function (value) {
                    console.log("Text is Value : ", value, message, i);
                browser.sleep(9000);
                if(value == message ){
                    browser.sleep(9000);
                    console.log("Text : " + i);
                  element(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[12]/a")).click();
                  browser.sleep(9000);
                  element(by.xpath("(//*[@id='invCalId'][text()='Yes'])[1]")).click();

                    }else{
             browser.driver.sleep(4000);
                        console.log("Not associated with Specified Quarter");
                    }
                });
            }
           // callback();
           });
        },

        quarterVariableCalculateButton: function (callback) {
            browser.waitForAngular();
            browser.driver.sleep(9000);            
          return  element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr")).count().then(function (cnt) {
            var message = "VARIABLE";
          for (var i = 1; i < cnt; i++) {
                browser.sleep(9000);
                (element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[6]")).get(count)).getText().then(function (value) {
                    console.log("Text is Value : ", value, message, i);
                browser.sleep(9000);
                if(value == message ){
                    browser.sleep(9000);
                    console.log("Text : " + i);
                  element(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr[" + i + "]/td[12]/a")).click();
                  browser.sleep(9000);
                  element(by.xpath("(//*[@id='invCalId'][text()='Yes'])[1]")).click();

                    }else{
             browser.driver.sleep(4000);
                        console.log("Not associated with Specified Quarter");
                    }
                });
            }
           // callback();
           });
        },
        validateMonthlyBillingEscalationForSameRateDifferentPeriod:function (callback) {
            browser.waitForAngular();
            browser.sleep(12000);
            element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                console.log(value);
                if(value == true || value == "true"){
                    browser.sleep(5000); 
                    element(by.xpath("//*[@id='createnewversion']")).isPresent();
                    //console.log("test123");
                    element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(4000);
                        //Selecting Monthly from 2.2 section
                        element(by.xpath("//*[@id='2-4-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Monthly from 2.3 section
                        element(by.xpath("//*[@id='3-8-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='12-256-RADIO']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -No
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.2.
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                        browser.sleep(4000);
                        //2.9.3.3.--Yes
                        element(by.xpath("//*[@id='178-91-RADIO']")).click();
                        browser.sleep(6000);
                                //2.9.3.4---Add Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.3');
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(3000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(13000);
                        //2nd Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.4');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='179-eotFlag']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(11000);
                        //2.9.4--As a separate line in calculation
                        element(by.xpath("//*[@id='106-326-RADIO']")).click();
                        browser.sleep(4000);
                        //2.11. --Yes
                        element(by.xpath("//*[@id='125-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.12.-Generate separate invoices
                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                        browser.sleep(4000);
                        //  Fixed Billing Terms and Conditions – Unescalated   
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(4000);
                        //Variable Billing Terms and Conditions – Unescalated
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(11000);
                        callback();
                                      });
                                    });
                                });
                            });
                        });
                     }); 
                    //});
                }else{
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).isPresent();
                    element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(6000);
                        //Selecting Monthly from 2.2 section
                        element(by.xpath("//*[@id='2-4-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Monthly from 2.3 section
                        element(by.xpath("//*[@id='3-8-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='12-256-RADIO']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -No
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.2.
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                        browser.sleep(4000);
                        //2.9.3.3.--Yes
                        element(by.xpath("//*[@id='178-91-RADIO']")).click();
                        browser.sleep(4000);
                                //2.9.3.4---Add Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.3');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(13000);
                        //2nd Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.4');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='179-eotFlag']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(11000);
                        //2.9.4--As a separate line in calculation
                        element(by.xpath("//*[@id='106-326-RADIO']")).click();
                        browser.sleep(4000);
                        //2.11. --Yes
                        element(by.xpath("//*[@id='125-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.12.-Generate separate invoices
                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                        browser.sleep(4000);
                        //  Fixed Billing Terms and Conditions – Unescalated   
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(5000);
                        //Variable Billing Terms and Conditions – Unescalated
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(11000);
                        callback();
                              });
                           });
                        });
                    });
                //});
                }
            });
        },

        validateQuarterlyBillingEscalationForSameRateDifferentPeriod:function (callback) {
            browser.waitForAngular();
            browser.sleep(12000);
            element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                console.log(value);
                if(value == true || value == "true"){
                    browser.sleep(5000); 
                    element(by.xpath("//*[@id='createnewversion']")).isPresent();
                    //console.log("test123");
                    element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.3 section
                        element(by.xpath("//*[@id='3-9-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -No
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.2.
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                        browser.sleep(4000);
                        //2.9.3.3.--Yes
                        element(by.xpath("//*[@id='178-91-RADIO']")).click();
                        browser.sleep(6000);
                                //2.9.3.4---Add Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.3');
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(3000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(13000);
                        //2nd Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.4');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='179-eotFlag']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(11000);
                        //2.9.4--As a separate line in calculation
                        element(by.xpath("//*[@id='106-326-RADIO']")).click();
                        browser.sleep(4000);
                        //2.11. --Yes
                        element(by.xpath("//*[@id='125-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.12.-Generate separate invoices
                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                        browser.sleep(4000);
                        //  Fixed Billing Terms and Conditions – Unescalated   
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(4000);
                        //Variable Billing Terms and Conditions – Unescalated
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(11000);
                        callback();
                                      });
                                    });
                                });
                            });
                        });
                     }); 
                    //});
                }else{
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).isPresent();
                    element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(6000);
                        //Selecting Quarterly from 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.3 section
                        element(by.xpath("//*[@id='3-9-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -No
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.2.
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.2');
                        browser.sleep(4000);
                        //2.9.3.3.--Yes
                        element(by.xpath("//*[@id='178-91-RADIO']")).click();
                        browser.sleep(4000);
                                //2.9.3.4---Add Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.3');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(13000);
                        //2nd Row
                        element(by.xpath("//*[@id='179']/div/div[2]/a")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("(//*[@id='Escalation Rate-textBox'])[1]")).sendKeys('.4');
                        browser.sleep(4000);
                        element(by.xpath("(//*[@id='179-chkBox-all'])[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                        browser.sleep(4000);
                        element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='179-eotFlag']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        browser.sleep(11000);
                        //2.9.4--As a separate line in calculation
                        element(by.xpath("//*[@id='106-326-RADIO']")).click();
                        browser.sleep(4000);
                        //2.11. --Yes
                        element(by.xpath("//*[@id='125-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.12.-Generate separate invoices
                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                        browser.sleep(4000);
                        //  Fixed Billing Terms and Conditions – Unescalated   
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(5000);
                        //Variable Billing Terms and Conditions – Unescalated
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(11000);
                        callback();
                              });
                           });
                        });
                    });
                //});
                }
            });
        },

        validateQuarterlyBillingEscalationFor125:function (callback) {
            browser.waitForAngular();
            browser.sleep(12000);
            element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                console.log(value);
                if(value == true || value == "true"){
                    browser.sleep(5000); 
                    element(by.xpath("//*[@id='createnewversion']")).isPresent();
                    //console.log("test123");
                    element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.3 section
                        element(by.xpath("//*[@id='3-9-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -NO
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                        browser.sleep(3000);
                        //2.9.3.3.Do you configure different Escalation rate for different period? --No
                        element(by.xpath("//*[@id='178-92-RADIO']")).click();
                        browser.sleep(3000);
                        //2.9.4.How should escalation be applied---Escalation should be applied to the billing rates itself (ie. $100/FFH with 25% escalation will show as $125/FFH)
                        element(by.xpath("//*[@id='106-327-RADIO']")).click();
                        browser.sleep(4000);
                        /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }                                                        
                        browser.sleep(4000);*/
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(6000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(3000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('10');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[5]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                                      });
                                    });
                                });
                            });
                        });
                     });
                }else{
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='commit']")).isPresent();
                    element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                        browser.sleep(6000);
                        //Selecting Quarterly from 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(4000);
                        //Selecting Quarterly from 2.3 section
                        element(by.xpath("//*[@id='3-9-RADIO']")).click();
                        browser.sleep(4000);
                        //After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                        browser.sleep(4000);                            
                        element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.7-a) Specified day of the month
                        element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                }else{
                                    console.log("Already 2.7 Specified day of the month selected ");
                                } 
                           // });
                        browser.sleep(4000);
                        //2.7 Actual day
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(4000);                                                
                        element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                        browser.sleep(4000);
                        //2.8 No selection
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.Contract allow for billing Escalation -Yes
                        element(by.xpath("//*[@id='20-91-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.3.Different escalation rate for different type of billing -NO
                        element(by.xpath("//*[@id='22-92-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(3000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                        browser.sleep(4000);
                        //2.9.3.3.Do you configure different Escalation rate for different period? --No
                        element(by.xpath("//*[@id='178-92-RADIO']")).click();
                        browser.sleep(4000);
                        //2.9.4.How should escalation be applied?--Escalation should be applied to the billing rates itself (ie. $100/FFH with 25% escalation will show as $125/FFH)
                        element(by.xpath("//*[@id='106-327-RADIO']")).click();
                        browser.sleep(4000);
                        /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }                                                        
                        browser.sleep(4000);*/
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='99-92-RADIO']")).click();
                        browser.sleep(6000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);              
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.sleep(4000);
                        //5.1.1.4.Please select the fees mode
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                            console.log(value);
                                if(value==true ){
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                        browser.sleep(4000);
                        element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('10');
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[5]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                }else{
                                    console.log("Not associated with Other Contract");
                                }
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).click();
                        browser.sleep(5000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                              });
                           });
                        });
                    });
                }
            });
        },

        
validateQuarterlyBillingEscalationlowestLevelOfDetail:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -NO
                element(by.xpath("//*[@id='22-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                //2.9.4.1--Show escalation by unit/by billing type (lowest level of detail)
                element(by.xpath("//*[@id='107-328-RADIO']")).click();
                browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                        browser.sleep(3000);
                
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
               //Selecting Quarterly from 2.2 section
               element(by.xpath("//*[@id='2-5-RADIO']")).click();
               browser.sleep(4000);
               //Selecting Quarterly from 2.3 section
               element(by.xpath("//*[@id='3-9-RADIO']")).click();
               browser.sleep(4000);
               //After (After end of billing period)
               element(by.xpath("//*[@id='5-19-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
               browser.sleep(4000);                            
               element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.7-a) Specified day of the month
               element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='14-232-chkbox']")).click();
                       }else{
                           console.log("Already 2.7 Specified day of the month selected ");
                       } 
                  // });
               browser.sleep(4000);
               //2.7 Actual day
               element(by.xpath("//*[@id='93-256-RADIO']")).click();
               browser.sleep(4000);                                                
               element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.8 No selection
               element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
               //2.9.3.3.Do you configure different Escalation rate for different period? --No
               element(by.xpath("//*[@id='178-92-RADIO']")).click();
               browser.sleep(2000);
               //2.9.4.How should escalation be applied?--As a separate line in calculation
               element(by.xpath("//*[@id='106-326-RADIO']")).click();
               browser.sleep(4000);
               //2.9.4.1--Show escalation by unit/by billing type (lowest level of detail)
               element(by.xpath("//*[@id='107-328-RADIO']")).click();
               browser.sleep(4000);
               /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='102-1-chkbox']")).click();
                       }else{
                           console.log("Not associated with Other Contract");
                       }                                                        
               browser.sleep(4000);*/
               element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='26-104-RADIO']")).click();
               browser.sleep(6000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
               browser.sleep(4000);
               element(by.xpath("//*[@id='99-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);              
               element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(2000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='84-605-chkbox']")).click();
                       browser.sleep(3000);
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                      });
                   });
                });
            });
        }
    });
},

validateQuarterlyBillingEscalationlowestLevelOfIndividualDetail:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-2-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-2-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -NO
                element(by.xpath("//*[@id='22-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                //2.9.4.1--Show escalation by unit/by billing type (lowest level of detail)
                element(by.xpath("//*[@id='107-328-RADIO']")).click();
                browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                        browser.sleep(3000);
                
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-2-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-2-RADIO']")).isSelected();
                browser.sleep(6000);
               //Selecting Quarterly from 2.2 section
               element(by.xpath("//*[@id='2-5-RADIO']")).click();
               browser.sleep(4000);
               //Selecting Quarterly from 2.3 section
               element(by.xpath("//*[@id='3-9-RADIO']")).click();
               browser.sleep(4000);
               //After (After end of billing period)
               element(by.xpath("//*[@id='5-19-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
               browser.sleep(4000);                            
               element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.7-a) Specified day of the month
               element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='14-232-chkbox']")).click();
                       }else{
                           console.log("Already 2.7 Specified day of the month selected ");
                       } 
                  // });
               browser.sleep(4000);
               //2.7 Actual day
               element(by.xpath("//*[@id='93-256-RADIO']")).click();
               browser.sleep(4000);                                                
               element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.8 No selection
               element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
               //2.9.3.3.Do you configure different Escalation rate for different period? --No
               element(by.xpath("//*[@id='178-92-RADIO']")).click();
               browser.sleep(2000);
               //2.9.4.How should escalation be applied?--As a separate line in calculation
               element(by.xpath("//*[@id='106-326-RADIO']")).click();
               browser.sleep(4000);
               //2.9.4.1--Show escalation by unit/by billing type (lowest level of detail)
               element(by.xpath("//*[@id='107-328-RADIO']")).click();
               browser.sleep(4000);
               /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='102-1-chkbox']")).click();
                       }else{
                           console.log("Not associated with Other Contract");
                       }                                                        
               browser.sleep(4000);*/
               element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='26-104-RADIO']")).click();
               browser.sleep(6000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
               browser.sleep(4000);
               element(by.xpath("//*[@id='99-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);              
               element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(2000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='84-605-chkbox']")).click();
                       browser.sleep(3000);
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                      });
                   });
                });
            });
        }
    });
},

verifyQuarterlyEscalationUnitIDTxt: function () {
    browser.driver.sleep(5000);
      return cem.findElement(currentPage,'escalationBillingTypeTxt').getText().then(function (amount) {
        var value = amount.toString().split(" ").join(" ").replace(/Escalation fee - Fixed Fee -/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf(' - 40.0%');
 var totalAmounts = ((value.substr(init + 1,  fin - init -1)));
 browser.driver.sleep(4000);
        console.log("Unit Id:" + totalAmounts);                
        invoiceUnitId = totalAmounts;    
    });
},

billingScheduleOpsDataUnitIdTxt: function () {
    browser.driver.sleep(8000);
    return cem.findElement(currentPage,'opsDataUnitIdTxt').getText().then(function (value) {        
        invoiceUnitId = value;
        browser.driver.sleep(4000);
        cem.findElement(currentPage,'opsDataUnitIdTxt1').getText().then(function (value) {        
            invoiceUnitIds = value;
        });
    });

},

escalationBillingVariableTypeTxt:function () {
    browser.driver.sleep(7000);
    return cem.findElement(currentPage,'escalationBillingVariableTypeTxt').getText().then(function (unit) {
        var value = unit.toString().split(" ").join(" ").replace(/Escalation Fee - Variable fee -/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf(' - 40.0%');
 var totalAmounts = ((value.substr(init + 1,  fin - init -1)));
 browser.driver.sleep(4000);
        console.log("Unit Id:" + totalAmounts);                
        invoiceUnitId = totalAmounts;
        browser.driver.sleep(5000);
        cem.findElement(currentPage,'escalationBillingVariableTypeTxt1').getText().then(function (amount) {
            var value = amount.toString().split(" ").join(" ").replace(/Escalation Fee - Variable fee -/g, "");
            var init = value.indexOf('');
            var fin = value.indexOf(' - 40.0%');
     var totalAmount = ((value.substr(init + 1,  fin - init -1)));
     browser.driver.sleep(4000);
            console.log("Unit Id:" + totalAmount);                
            invoiceUnitIds = totalAmount;

        });
    });
},

billingScheduleSearchFld: function () {
    browser.waitForAngular();
    browser.driver.sleep(7000);
    cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
    browser.sleep(3000);
    cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys(protractor.Key.DELETE);
    browser.sleep(3000);
   return cem.findElement(currentPage,'billingScheduleSearchFld').sendKeys('VARIABLE CS25624');
},

escalationBillingVariableType: function() {
	browser.waitForAngular();
	browser.driver.sleep(11000);
	cem.findElement(currentPage, 'billingScheduleCalculatBtn').click();
    browser.driver.sleep(8000);
    cem.findElement(currentPage, 'billingScheduleCalculateConfOkBtn').click();
    browser.driver.sleep(8000);
	return cem.findElement(currentPage, 'escalationBillingVariableType').getText().then(function (value) {
        console.log("Escalation Variable Header Text: " + value);
    });
},

validateQuarterlyBillingEscalationCombineDetail:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -NO
                element(by.xpath("//*[@id='22-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                //2.9.4.1--Combine all escalation into one line
                element(by.xpath("//*[@id='107-330-RADIO']")).click();
                browser.sleep(4000);
                //2.12--Combine as a single invoice
               element(by.xpath("//*[@id='126-418-RADIO']")).click();
               browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                        browser.sleep(3000);
                
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
               //Selecting Quarterly from 2.2 section
               element(by.xpath("//*[@id='2-5-RADIO']")).click();
               browser.sleep(4000);
               //Selecting Quarterly from 2.3 section
               element(by.xpath("//*[@id='3-9-RADIO']")).click();
               browser.sleep(4000);
               //After (After end of billing period)
               element(by.xpath("//*[@id='5-19-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
               browser.sleep(4000);                            
               element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.7-a) Specified day of the month
               element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='14-232-chkbox']")).click();
                       }else{
                           console.log("Already 2.7 Specified day of the month selected ");
                       } 
                  // });
               browser.sleep(4000);
               //2.7 Actual day
               element(by.xpath("//*[@id='93-256-RADIO']")).click();
               browser.sleep(4000);                                                
               element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.8 No selection
               element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
               //2.9.3.3.Do you configure different Escalation rate for different period? --No
               element(by.xpath("//*[@id='178-92-RADIO']")).click();
               browser.sleep(2000);
               //2.9.4.How should escalation be applied?--As a separate line in calculation
               element(by.xpath("//*[@id='106-326-RADIO']")).click();
               browser.sleep(4000);
               //2.9.4.1--Combine all escalation into one line
               element(by.xpath("//*[@id='107-330-RADIO']")).click();
               browser.sleep(4000);
               //2.12--Combine as a single invoice
               element(by.xpath("//*[@id='126-418-RADIO']")).click();
               browser.sleep(4000);
               /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='102-1-chkbox']")).click();
                       }else{
                           console.log("Not associated with Other Contract");
                       }                                                        
               browser.sleep(4000);*/
               element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='26-104-RADIO']")).click();
               browser.sleep(6000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
               browser.sleep(4000);
               element(by.xpath("//*[@id='99-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);              
               element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(2000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='84-605-chkbox']")).click();
                       browser.sleep(3000);
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                      });
                   });
                });
            });
        }
    });
},
escalationBillingTypeCount: function() {
    var count = "1";
	browser.waitForAngular();
    browser.driver.sleep(8000);
	return element.all(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'][contains(.,'Escalation -')]")).count().then(function (value) {
        console.log("Escalation Header Text Count: " + value);
        if(value==count ){
            browser.sleep(4000);
            console.log("Combined all Escalation into one line");
             }else{
                 console.log("Not Combined all Escalation into one line");
             }
    });
},

validateQuarterlyBillingEscalationSplitbySite:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -NO
                element(by.xpath("//*[@id='22-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                //2.9.4.1--Show escalation separately for Fixed and Variablee
                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                browser.sleep(4000);
                //2.12--Combine as a single invoice
               element(by.xpath("//*[@id='126-418-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                console.log(value);
                    if(value==true  || value == "true" ){
                    browser.sleep(4000);
                    //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                    console.log("Associated with Multi Project Ids");                        
                    }else{
                        //console.log("Associated with Multi Project Ids");
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();                            
                    }                                                        
            browser.sleep(7000);
            //2.10.1--Is the billing split by Site/Equipment?
            element(by.xpath("//*[@id='103-324-RADIO']")).click();
            browser.sleep(5000);
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[5]"))).perform();
            browser.sleep(5000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[9]")).click();
            browser.sleep(5000);
            browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
            browser.sleep(3000);
            browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
            browser.sleep(3000);
            browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
            browser.sleep(3000);
            browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
            browser.sleep(3000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]")).click();
            //browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]"))).perform();
            browser.sleep(5000);              
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]")).click();
               browser.sleep(4000);
               browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
               browser.sleep(3000);
               browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
               browser.sleep(3000);
               browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
               browser.sleep(4000);               
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                        browser.sleep(3000);
                
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                                });
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
               //Selecting Quarterly from 2.2 section
               element(by.xpath("//*[@id='2-5-RADIO']")).click();
               browser.sleep(4000);
               //Selecting Quarterly from 2.3 section
               element(by.xpath("//*[@id='3-9-RADIO']")).click();
               browser.sleep(4000);
               //After (After end of billing period)
               element(by.xpath("//*[@id='5-19-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
               browser.sleep(4000);                            
               element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
               browser.sleep(6000);
               //2.7-a) Specified day of the month
               element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='14-232-chkbox']")).click();
                       }else{
                           console.log("Already 2.7 Specified day of the month selected ");
                       } 
                  // });
               browser.sleep(6000);
               //2.7 Actual day
               element(by.xpath("//*[@id='93-256-RADIO']")).click();
               browser.sleep(4000);                                                
               element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.8 No selection
               element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
               //2.9.3.3.Do you configure different Escalation rate for different period? --No
               element(by.xpath("//*[@id='178-92-RADIO']")).click();
               browser.sleep(2000);
               //2.9.4.How should escalation be applied?--As a separate line in calculation
               element(by.xpath("//*[@id='106-326-RADIO']")).click();
               browser.sleep(4000);
              //2.9.4.1--Show escalation separately for Fixed and Variablee
              element(by.xpath("//*[@id='107-329-RADIO']")).click();
              browser.sleep(4000);
              //2.12--Combine as a single invoice
              element(by.xpath("//*[@id='126-418-RADIO']")).click();
              browser.sleep(5000);
               element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true  || value == "true" ){
                       browser.sleep(4000);
                       //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                       console.log("Associated with Multi Project Ids");                        
                       }else{
                           //console.log("Associated with Multi Project Ids");
                           element(by.xpath("//*[@id='102-1-chkbox']")).click();                            
                       }                                                        
               browser.sleep(7000);
               //2.10.1--Is the billing split by Site/Equipment?
               element(by.xpath("//*[@id='103-324-RADIO']")).click();
               browser.sleep(5000);
               browser.driver.actions().doubleClick(element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[5]"))).perform();
               browser.sleep(5000);              
               element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[9]")).click();
               browser.sleep(5000);
               browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
               browser.sleep(3000);
               browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
              browser.sleep(3000);
              browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
              browser.sleep(3000);
              browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
               browser.sleep(4000);
               element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]")).click();
               //browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]"))).perform();
               browser.sleep(4000);              
               element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[12]")).click();
               browser.sleep(4000);
               browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
               browser.sleep(3000);
               browser.driver.actions().sendKeys(protractor.Key.ARROW_DOWN).perform();
               browser.sleep(3000);
               browser.driver.actions().sendKeys(protractor.Key.TAB).perform();
               browser.sleep(4000);
               element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='26-104-RADIO']")).click();
               browser.sleep(6000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
               browser.sleep(4000);
               element(by.xpath("//*[@id='99-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);              
               element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(2000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='84-605-chkbox']")).click();
                       browser.sleep(3000);
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                         });
                      });
                   });
                });
            });
        }
    });
},

validationOfEquipmentAndProjectId: function () {
    browser.waitForAngular();
    browser.driver.sleep(8000);
    return TestHelper.isElementPresent(currentPage,'generalContractTermsAndConditions').then(function(){
    browser.driver.sleep(4000);
    cem.findElement(currentPage,'generalContractTermsAndConditions').click();
    browser.driver.sleep(5000);
    cem.findElement(currentPage,'equipmentSNID').getText().then(function(value){
        console.log("Ist Equipment ID", value);
        equipmentId1 = value;
    cem.findElement(currentPage,'equipmentSNID1').getText().then(function(value){
            console.log("IInd Equipment ID", value);
            equipmentId2 = value;
    cem.findElement(currentPage,'proJectID').getText().then(function(value){
                console.log("Ist Project ID", value);
                projectId1 = value;
    cem.findElement(currentPage,'projectID1').getText().then(function(value){
                    console.log("IInd Project ID", value);
                    projectId2 = value;
                    });
                });
            });
        });
    });  
},

validationProjectAndEquipmentIdTxt1: function () {
    browser.driver.sleep(10000);
    return cem.findElement(currentPage,'invoiceProjectID1').getText().then(function (value) {        
        projectId1 = value;
        console.log("Ist Project ID", projectId1); 
        browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
            equipmentId1 = value;
            console.log("Ist Equipment ID", equipmentId1); 
            browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceProjectID2').click().then(function () {        
        browser.driver.sleep(9000);
    cem.findElement(currentPage,'invoiceProjectID2').getText().then(function (value) {        
        projectId2 = value;
        console.log("IInd Project ID", projectId2); 
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
                        equipmentId2 = value;
                        console.log("IInd Equipment ID", equipmentId2);
                    });
                });
            });
        });
    });

},

/*validationProjectAndEquipmentIdTxt: function () {
    browser.driver.sleep(10000);
    return cem.findElement(currentPage,'invoiceProjectID1').getText().then(function (value) {        
        projectId1 = value;
        console.log("Ist Project ID", projectId1); 
        browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
            equipmentId1 = value;
            console.log("Ist Equipment ID", equipmentId1); 
            browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceEquipmentID2').getText().then(function (value) {        
        equipmentId2 = value;
                console.log("IInd Equipment ID", equipmentId1); 
                browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceProjectID2').click().then(function () {        
        browser.driver.sleep(9000);
    cem.findElement(currentPage,'invoiceProjectID2').getText().then(function (value) {        
        projectId2 = value;
        console.log("IInd Project ID", projectId2); 
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
                        equipmentId1 = value;
                        console.log("Ist Equipment ID", equipmentId1);
    cem.findElement(currentPage,'invoiceEquipmentID2').getText().then(function (value) {        
                            equipmentId2 = value;
                            console.log("IInd Equipment ID", equipmentId2);
                           });
                        });
                    });
                });
            });
        });
    });

},*/

validateQuarterlyBillingEscalationSplitbySitePercentage:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                //2.9.Contract allow for billing Escalation -Yes
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000);
                //2.9.3.Different escalation rate for different type of billing -NO
                element(by.xpath("//*[@id='22-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
                browser.sleep(3000);
                //2.9.3.3.Do you configure different Escalation rate for different period? --No
                element(by.xpath("//*[@id='178-92-RADIO']")).click();
                browser.sleep(2000);
                //2.9.4.How should escalation be applied?--As a separate line in calculation
                element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                //2.9.4.1--Show escalation separately for Fixed and Variablee
                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                browser.sleep(4000);
                //2.12--Combine as a single invoice
               element(by.xpath("//*[@id='126-418-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                console.log(value);
                    if(value==true  || value == "true" ){
                    browser.sleep(4000);
                    //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                    console.log("Associated with Multi Project Ids");                        
                    }else{
                        //console.log("Associated with Multi Project Ids");
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();                            
                    }                                                        
            browser.sleep(7000);
            //2.10.1--Is the billing split by percentage across different Project ID's
            element(by.xpath("//*[@id='103-325-RADIO']")).click();
            browser.sleep(5000);
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[1].value'])[1]"))).perform();
            browser.sleep(3000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[8]")).sendKeys('50');
            browser.sleep(5000);
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[1]"))).perform();
            browser.sleep(3000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[13]")).sendKeys('50');
            browser.sleep(4000);        
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[1]"))).perform();
            browser.sleep(3000);              
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[9]")).sendKeys('50');
               browser.sleep(4000);
               browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[2]"))).perform();
            browser.sleep(3000);              
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[14]")).sendKeys('50');
               browser.sleep(4000);               
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='59-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                        browser.sleep(3000);
                
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                                });
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
               //Selecting Quarterly from 2.2 section
               element(by.xpath("//*[@id='2-5-RADIO']")).click();
               browser.sleep(4000);
               //Selecting Quarterly from 2.3 section
               element(by.xpath("//*[@id='3-9-RADIO']")).click();
               browser.sleep(4000);
               //After (After end of billing period)
               element(by.xpath("//*[@id='5-19-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
               browser.sleep(4000);                            
               element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
               browser.sleep(6000);
               //2.7-a) Specified day of the month
               element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='14-232-chkbox']")).click();
                       }else{
                           console.log("Already 2.7 Specified day of the month selected ");
                       } 
                  // });
               browser.sleep(6000);
               //2.7 Actual day
               element(by.xpath("//*[@id='93-256-RADIO']")).click();
               browser.sleep(4000);                                                
               element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
               browser.sleep(4000);
               //2.8 No selection
               element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
               //2.9.3.3.Do you configure different Escalation rate for different period? --No
               element(by.xpath("//*[@id='178-92-RADIO']")).click();
               browser.sleep(2000);
               //2.9.4.How should escalation be applied?--As a separate line in calculation
               element(by.xpath("//*[@id='106-326-RADIO']")).click();
               browser.sleep(4000);
              //2.9.4.1--Show escalation separately for Fixed and Variablee
              element(by.xpath("//*[@id='107-329-RADIO']")).click();
              browser.sleep(4000);
              //2.12--Combine as a single invoice
              element(by.xpath("//*[@id='126-418-RADIO']")).click();
              browser.sleep(5000);
               element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true  || value == "true" ){
                       browser.sleep(4000);
                       //element(by.xpath("//*[@id='102-1-chkbox']")).click();
                       console.log("Associated with Multi Project Ids");                        
                       }else{
                           //console.log("Associated with Multi Project Ids");
                           element(by.xpath("//*[@id='102-1-chkbox']")).click();                            
                       }                                                        
               browser.sleep(7000);
               //2.10.1--Is the billing split by percentage across different Project ID's
            element(by.xpath("//*[@id='103-325-RADIO']")).click();
            browser.sleep(5000);
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[1].value'])[1]"))).perform();
            browser.sleep(3000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[8]")).sendKeys('50');
            browser.sleep(5000);
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[1]"))).perform();
            browser.sleep(3000);
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[13]")).sendKeys('50');
            browser.sleep(4000);        
            browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[1]"))).perform();
            browser.sleep(3000);              
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[9]")).sendKeys('50');
               browser.sleep(4000);
               browser.driver.actions().doubleClick(element(by.xpath("(//*[@ng-input='row.entity.columDef[2].value'])[2]"))).perform();
            browser.sleep(3000);              
            element(by.xpath("(//*[@ng-repeat='(colRenderIndex, col) in colContainer.renderedColumns track by col.uid'])[14]")).sendKeys('50');
               browser.sleep(4000);
               element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='26-104-RADIO']")).click();
               browser.sleep(6000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
               browser.sleep(4000);
               element(by.xpath("//*[@id='99-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);              
               element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(2000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                       element(by.xpath("//*[@id='84-605-chkbox']")).click();
                       browser.sleep(3000);
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                         });
                      });
                   });
                });
            });
        }
    });
},

validationOfEquipmentAndProject: function () {
    browser.waitForAngular();
    browser.driver.sleep(8000);
    return TestHelper.isElementPresent(currentPage,'generalContractTermsAndConditions').then(function(){
    browser.driver.sleep(4000);
    cem.findElement(currentPage,'generalContractTermsAndConditions').click();
    browser.driver.sleep(5000);
    // cem.findElement(currentPage,'equipmentSNID').getText().then(function(value){
    //     console.log("Ist Equipment ID", value);
    //     equipmentId1 = value;
    // cem.findElement(currentPage,'equipmentSNID1').getText().then(function(value){
    //         console.log("IInd Equipment ID", value);
    //         equipmentId2 = value;
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[1]")).getText().then(function(value){
                console.log("Ist Project ID", value);
                multiProjectId1 = value;
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[2]")).getText().then(function(value){
                    console.log("IInd Project ID", value);
                    multiProjectId2 = value;
                    });
                });
            });
        //});
    //});  
},

validationProjectAndEquipmentId: function () {
    browser.driver.sleep(10000);
    return cem.findElement(currentPage,'invoiceProjectID1').getText().then(function (value) {        
        multiProjectId2 = value;
        console.log("Ist Project ID", multiProjectId2); 
        browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
        invoiceUnitId = value;
            console.log("Ist Equipment ID", invoiceUnitId); 
            browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceEquipmentID2').getText().then(function (value) {        
        invoiceUnitIds = value;
                console.log("IInd Equipment ID", invoiceUnitIds); 
                browser.driver.sleep(4000);
    cem.findElement(currentPage,'invoiceProjectID2').click().then(function () {        
        browser.driver.sleep(9000);
    cem.findElement(currentPage,'invoiceProjectID2').getText().then(function (value) {        
        multiProjectId1 = value;
        console.log("IInd Project ID", multiProjectId1); 
    cem.findElement(currentPage,'invoiceEquipmentID1').getText().then(function (value) {        
        invoiceUnitId = value;
                        console.log("Ist Equipment ID", invoiceUnitId);
    cem.findElement(currentPage,'invoiceEquipmentID2').getText().then(function (value) {        
        invoiceUnitIds = value;
                            console.log("IInd Equipment ID", invoiceUnitIds);
                           });
                        });
                    });
                });
            });
        });
    });

},

validateQuarterlyFixedBillingDescriptionTmplate:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.8 No selection
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
                //2.11.Configure Description Templates -No
                element(by.xpath("//*[@id='125-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys('Fixed Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys('Variable Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys('Milestone Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys('Escalation Billing Type');
                browser.sleep(4000);
                element(by.xpath("//*[@id='126-418-RADIO']")).click();
                //element(by.xpath("//*[@id='114-402-button']")).click();
                browser.sleep(3000);               
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(3000);
                element(by.xpath("(//*[@class='btn btn-info btn-lg'])[14]")).click();
                browser.sleep(4000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('200');
               browser.sleep(4000);
               browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
               browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(3000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                browser.sleep(3000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                              });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //2.7-a) Specified day of the month
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Already 2.7 Specified day of the month selected ");
                        } 
                   // });
                browser.sleep(4000);
                //2.7 Actual day
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);                                                
                element(by.xpath("//*[@id='15-SELECT']/option[text()='20th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='2nd month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                 //2.8 No selection
                 element(by.xpath("//*[@id='19-92-RADIO']")).click();
               browser.sleep(4000);
               //2.9.Contract allow for billing Escalation -Yes
               element(by.xpath("//*[@id='20-91-RADIO']")).click();
               browser.sleep(4000);
               //2.9.3.Different escalation rate for different type of billing -NO
               element(by.xpath("//*[@id='22-92-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.4');
               browser.sleep(3000);
                //2.11.Configure Description Templates -No
                element(by.xpath("//*[@id='125-92-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='114_rich_insert_html']")).sendKeys('Fixed Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='115_rich_insert_html']")).sendKeys('Variable Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='116_rich_insert_html']")).sendKeys('Milestone Billing Type');
                browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                 browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='117_rich_insert_html']")).sendKeys('Escalation Billing Type');
                browser.sleep(4000);
                element(by.xpath("//*[@id='126-418-RADIO']")).click();
                //element(by.xpath("//*[@id='114-402-button']")).click();
                browser.sleep(3000);               
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(3000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
               element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='84-187-chkbox']")).getAttribute('checked').then(function(value){
                   console.log(value);
                       if(value==true ){
                       browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(3000);
                element(by.xpath("(//*[@class='btn btn-info btn-lg'])[14]")).click();
                browser.sleep(4000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(3000);
               element(by.xpath("(//*[@name='124-textBox'])[1]")).sendKeys('200');
               browser.sleep(4000);
               browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
               browser.sleep(4000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(3000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                browser.sleep(3000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                      });
                   });
                });
            });
        }
    });
},

fixedVariableBillingDescriptionTemplate: function () {
    browser.driver.sleep(13000);
    var type = 'FIXED';
    var esc ="ESCALATION";
    var type1 = 'VARIABLE';
    var sn = 'All';
    var fixed = 'Fixed Billing Type';
    var escalation ="Escalation Billing Type";
    var variable = 'Variable Billing Type';
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
        browser.driver.sleep(11000);  
    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[2]")).getText().then(function (value) {
            console.log("UNIT SN: "+ value);
            assert.equal(value, sn);
   element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
            console.log("Fixed Type: "+ value);
            assert.equal(value, type);
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[1]")).getText().then(function (value) {
                console.log("Fixed Billing Description: "+ value);
                assert.equal(value, fixed);
                element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
                    console.log("Escalation Type: "+ value);
                    assert.equal(value, esc);
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[6]")).getText().then(function (value) {
                    console.log("Escalation Billing Description: "+ value);
                    assert.equal(value, escalation);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[12]")).getText().then(function (value) {
                        console.log("Variable Type: "+ value);
                        assert.equal(value, type1);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[11]")).getText().then(function (value) {
                        console.log("Variable Billing Description: "+ value);
                        assert.equal(value, variable);
                             });
                           });
                         });
                       });
                   });
                });
            });    
        });  
    });
},
milestoneBillingDescriptionTemplate: function () {
    browser.driver.sleep(11000);
    var type = 'ADDER';
    var sn = 'All';
    var milestone = 'Milestone Billing Type';
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
        browser.driver.sleep(11000);
    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[2]")).getText().then(function (value) {
            console.log("UNIT SN: "+ value);
            assert.equal(value, sn);
   element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
            console.log("Milestone Type: "+ value);
            assert.equal(value, type);
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[1]")).getText().then(function (value) {
                console.log("Milestone Billing Description: "+ value);
                assert.equal(value, milestone);
 
                   });
                });
            });    
        });  
    });
},

validateFixedBillingAmountForEntireContract:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(6000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        } 
               /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                browser.sleep(4000);                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(6000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        } 
               /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                browser.sleep(4000);                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(6000);                        
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(9000);
            callback();
                   });
                   });
                });
            });
        }
    });
},

validateInvoiceFixedBillingAmountForEntireContract: function () {
    browser.driver.sleep(5000);
    var price = '400.00';
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
   element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[4]")).getText().then(function (value) {
            console.log("Unit Price: "+ value);
            assert.equal(value, price);
    element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
                console.log("PeriodEvent Date: "+ value);
    element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[9]")).getText().then(function (value) {
                    console.log("Unit Price: "+ value);
                    assert.equal(value, price);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[11]")).getText().then(function (value) {
                        console.log("PeriodEvent Date: "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[14]")).getText().then(function (value) {
                            console.log("Unit Price: "+ value);
                            assert.equal(value, price); 
                           });
                        }); 
                   });
                });
            });    
        });  
    });
},

validateFixedBillingAmountForDifferentDateRanges:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--Fixed billing amount at different start and end period
                element(by.xpath("//*[@id='26-105-RADIO']")).click();
                browser.sleep(4000);
                //4.1.2.---Add Row
                element(by.xpath("//*[@id='28']/div[5]/div[2]/a")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys('400');
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
               //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
               browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
               //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
               browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(4000);                
                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);                
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
                 //4.1.2.---Add Row
                 element(by.xpath("//*[@id='28']/div[5]/div[2]/a")).click();
                 browser.sleep(4000);
                 element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys('400');
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                 browser.sleep(3000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);                
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                 browser.sleep(11000);
            element(by.xpath("//*[@id='99-92-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                                });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--Fixed billing amount at different start and end period
                element(by.xpath("//*[@id='26-105-RADIO']")).click();
                browser.sleep(5000);
                //4.1.2.---Add Row
                element(by.xpath("//*[@id='28']/div[5]/div[2]/a")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys('400');
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
               //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
               browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
               //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
               browser.sleep(3000); 
               element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                browser.sleep(4000);                
                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);   
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    //console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
             //4.1.2.---Add Row
             element(by.xpath("//*[@id='28']/div[5]/div[2]/a")).click();
             browser.sleep(4000);
             element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
            browser.sleep(3000);
            element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
            browser.sleep(4000);
            element(by.xpath("(//*[@name='28-textBox'])[1]")).sendKeys('400');
            browser.sleep(3000);
            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
            browser.sleep(3000);
            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
            //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
            browser.sleep(3000); 
            element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
             browser.sleep(4000);
             element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
             browser.sleep(4000);
             element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
             browser.sleep(4000);
             element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
             browser.sleep(4000);
             element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
             browser.sleep(3000);
             element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
            //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
            browser.sleep(3000); 
            element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
             browser.sleep(4000);
             element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
             browser.sleep(4000);                
             element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
             browser.sleep(4000);
             element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
             browser.sleep(4000);
             element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
             browser.sleep(11000);                        
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(4000);                        
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(9000);
            callback();
                       });
                      });
                   });
                });
            });
        }
    });
},

validateNoFixedBilling1:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quartely from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quartely from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                //element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                //browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='93-256-RADIO']")).click();  
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode---One rate across the entire contract timeline
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(4000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Quartely from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quartely from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(4000);
                //After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);                            
                element(by.xpath("//*[@id='12-SELECT']/option[text()='30th']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        } 
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();                                                       
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode--One rate across the entire contract timeline
               element(by.xpath("//*[@id='59-137-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
               browser.sleep(3000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
               browser.sleep(4000);
               element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys('10');
               browser.sleep(4000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='84-188-chkbox']")).click();
                browser.sleep(5000);                        
                element(by.xpath("//*[@id='commit']")).click().then(function () {
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                        });
                   });
                });
            });
        }
    });
},

validateVariableDifferentRatesAcrossDifferentTimePeriods:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode---Different rates across different time periods
               element(by.xpath("//*[@id='59-138-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.2---Add Row
               element(by.xpath("//*[@id='61']/div[5]/div[2]/a")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
              browser.sleep(3000); 
              element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
              //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
              browser.sleep(3000); 
              element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
               browser.sleep(4000);                
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                                
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
                browser.sleep(3000);
                 //5.1.1.2---Add Row
                 element(by.xpath("//*[@id='61']/div[5]/div[2]/a")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                 browser.sleep(3000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);                
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                 browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(4000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(3000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode---Different rates across different time periods
               element(by.xpath("//*[@id='59-138-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.2.---Add Row
               element(by.xpath("//*[@id='61']/div[5]/div[2]/a")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
              browser.sleep(3000); 
              element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
               browser.sleep(3000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
              //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
              browser.sleep(3000); 
              element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
               browser.sleep(4000);                
               element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
               browser.sleep(4000);
               element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                                
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
                browser.sleep(3000);
                 //5.1.1.2.---Add Row
                 element(by.xpath("//*[@id='61']/div[5]/div[2]/a")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[1]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                 browser.sleep(3000);
                 element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                //browser.actions().doubleClick(element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i"))).perform();
                browser.sleep(3000); 
                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                 browser.sleep(4000);                
                 element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[3]")).click();
                 browser.sleep(4000);
                 element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[7]")).click();
                 browser.sleep(4000);
                 element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                 browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       });
                      });
                   });
                });
            });
        }
    });
},
validateVariableDifferentRatesAcrossDifferentRangeofOperations:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-139-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.3---Add Row
               element(by.xpath("//*[@id='62']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('1000');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                                
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
                browser.sleep(3000);
                 //5.1.1.4.3---Add Row
               element(by.xpath("//*[@id='62']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('1000');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(4000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(5000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(4000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-139-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.3---Add Row
               element(by.xpath("//*[@id='62']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('1000');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(15000);                                
                TestHelper.isElementPresent(currentPage, 'billing293DeleteBtn').then(function(value){   
                    console.log(value);
                            if(value==true|| value=='true' ){
                            browser.sleep(5000);
                            element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='deleteRow']")).click();
                            browser.sleep(11000);
                            }else{
                                console.log("No data present");
                            }
                browser.sleep(3000);
                 //5.1.1.4.3---Add Row
               element(by.xpath("//*[@id='62']/div[5]/div[2]/a")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('10');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('1000');
               browser.sleep(4000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(15000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       });
                      });
                   });
                });
            });
        }
    });
},
verifyQuarterlyNoFixedBilling: function () {
   var variable ='VARIABLE'; 
    browser.driver.sleep(11000);
    return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
        console.log("Billing for Period Header Txt: "+ value);
        browser.driver.sleep(11000);
      cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
 console.log("Entitled Month :", periodDate);
 element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
        console.log("Type: "+ value);
        assert.equal(value, variable);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[3]")).getText().then(function (qunty) {
            console.log("Quantity : "+ qunty);
            browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[4]")).getText().then(function (unit) {
            console.log("Unit Price : "+ unit);
            browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (amount) {
        console.log("Amount(USD): "+ amount);
        var value = amount.toString().split(" ").join(" ").replace(/,/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf('.');
       var totalAmounts = ((value.substr(init ,  fin - init )));
        console.log("Total Amount: "+ totalAmounts);
        browser.sleep(2000);
        var total = parseInt(qunty) * parseInt(unit);
        console.log("Amount: "+ total);
        assert.equal(totalAmounts, total);
        browser.sleep(2000);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
        console.log("PeriodEvent Date: "+ value);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
            console.log("Type : "+ value);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[8]")).getText().then(function (quan) {
            console.log("Quantity : "+ quan);
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[9]")).getText().then(function (uni) {
            console.log("Unit Price : "+ uni);
            browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (amount1) {
        console.log("Amount(USD)1: "+ amount1);
        var value = amount1.toString().split(" ").join(" ").replace(/,/g, "");
        var init = value.indexOf('');
        var fin = value.indexOf('.');
       var totalAmounts1 = ((value.substr(init ,  fin - init )));
        console.log("Total Amount: "+ totalAmounts1);
        var total1 = parseInt(quan) * parseInt(uni);
        console.log("Amount: "+ total1);
        assert.equal(totalAmounts1, total1);
        browser.sleep(2000);
            element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (totalA) {
                return console.log("Total Amount : "+ totalA);
                                        });
                                    });
                                  });
                                });
                            });
                        });
                    });
                });
             });                      
           });                     
        });     
    });
});
},

validateVariableMonthlyDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='228-552-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("//*[@id='64-SELECT']/option[text()='Natural Gas Hours']")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("//*[@id='64-SELECT']/option[text()='Natural Gas Hours']")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
              browser.sleep(3000);              
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='228-552-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);               
                  //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
              browser.sleep(400);               
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

validateVariableQuartelyDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Quarterly
               element(by.xpath("//*[@id='228-553-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
               browser.sleep(5000);               
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Quarterly
               element(by.xpath("//*[@id='228-553-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
               browser.sleep(5000);               
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

validateVariableBillingWidgetDelectRows:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);                
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);                
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(9000);
            callback();
                   });
                });
            });
        }
    });
},

validateTermsAndConditionsBillingWidgetDelectRows:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[1]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000); 
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);                
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[1]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);                
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(9000);
            callback();
                   });
                });
            });
        }
    });
},
verifyQuarterlyNoFixedBilling1: function () {
    var variable ='VARIABLE'; 
     browser.driver.sleep(11000);
     return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
         console.log("Billing for Period Header Txt: "+ value);
         browser.driver.sleep(11000);
       cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
  console.log("Entitled Month :", periodDate);
  element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
         console.log("Type: "+ value);
         assert.equal(value, variable);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[3]")).getText().then(function (qunty) {
             console.log("Quantity : "+ qunty);
             var value = qunty.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var quantity = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ quantity);
             browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[4]")).getText().then(function (unit) {
             console.log("Unit Price : "+ unit);
             browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (amount) {
         console.log("Amount(USD): "+ amount);
         var value = amount.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var totalAmounts = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ totalAmounts);
         browser.sleep(2000);
         var total = parseInt(quantity) * parseInt(unit);
         console.log("Amount: "+ total);
         assert.equal(totalAmounts, total);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
             console.log("Type : "+ value);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[8]")).getText().then(function (quan) {
             console.log("Quantity : "+ quan);
             browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[9]")).getText().then(function (uni) {
             console.log("Unit Price : "+ uni);
             browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (amount1) {
         console.log("Amount(USD)1: "+ amount1);
         var value = amount1.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var totalAmounts1 = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ totalAmounts1);
         var total1 = parseInt(quan) * parseInt(uni);
         console.log("Amount: "+ total1);
         assert.equal(totalAmounts1, total1);
         browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (totalA) {
                 return console.log("Total Amount : "+ totalA);
                                         });
                                     });
                                   });
                                 });
                             });
                         });
                     });
                 });
              });                      
            });                     
         });     
     });
 });
 },

 validateVariableAnuallyYesDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Anually
               element(by.xpath("//*[@id='228-554-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.1.Please select the month for annaually ops refresh Frequency--May
               element(by.xpath("//*[@name='229-Select']/option[text()='May']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.Does the rate based on ops range ?---Yes
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
               browser.sleep(5000);               
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Anually
               element(by.xpath("//*[@id='228-554-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.1.Please select the month for annaually ops refresh Frequency--May
               element(by.xpath("//*[@name='229-Select']/option[text()='May']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.Does the rate based on ops range ?---Yes
               element(by.xpath("//*[@id='230-91-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('0');
              browser.sleep(5000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Ending Range-textBox'])[1]")).sendKeys('500');
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);                            
               element(by.xpath("//*[@id='64']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='64-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('10');
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Starting Range-textBox'])[1]")).sendKeys('501');
              browser.sleep(3000);              
              element(by.xpath("(//*[@id='64-eotFlag'])[1]")).click();
               browser.sleep(5000);               
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

validateVariableAnuallyNoDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Anually
               element(by.xpath("//*[@id='228-554-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.1.Please select the month for annaually ops refresh Frequency--May
               element(by.xpath("//*[@name='229-Select']/option[text()='May']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.Does the rate based on ops range ?---No
               element(by.xpath("//*[@id='230-92-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Anually
               element(by.xpath("//*[@id='228-554-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.1.Please select the month for annaually ops refresh Frequency--May
               element(by.xpath("//*[@name='229-Select']/option[text()='May']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

verifyQuarterlyNoFixedBillingNo: function () {
    var variable ='VARIABLE'; 
     browser.driver.sleep(11000);
     return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
         console.log("Billing for Period Header Txt: "+ value);
         browser.driver.sleep(11000);
       cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
  console.log("Entitled Month :", periodDate);
  element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
         console.log("Type: "+ value);
         assert.equal(value, variable);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[3]")).getText().then(function (qunty) {
             console.log("Quantity : "+ qunty);
             var value = qunty.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var quantity = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ quantity);
             browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[4]")).getText().then(function (unit) {
             console.log("Unit Price : "+ unit);
             browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[5]")).getText().then(function (amount) {
         console.log("Amount(USD): "+ amount);
         var value = amount.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var totalAmounts = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ totalAmounts);
         browser.sleep(2000);
         var total = parseInt(quantity) * parseInt(unit);
         console.log("Amount: "+ total);
         assert.equal(totalAmounts, total);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[7]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[8]")).getText().then(function (value) {
             console.log("Type : "+ value);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[8]")).getText().then(function (quan) {
             console.log("Quantity : "+ quan);
             browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[9]")).getText().then(function (uni) {
             console.log("Unit Price : "+ uni);
             browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[10]")).getText().then(function (amount1) {
         console.log("Amount(USD)1: "+ amount1);
         var value = amount1.toString().split(" ").join(" ").replace(/,/g, "");
         var init = value.indexOf('');
         var fin = value.indexOf('.');
        var totalAmounts1 = ((value.substr(init ,  fin - init )));
         console.log("Total Amount: "+ totalAmounts1);
         var total1 = parseInt(quan) * parseInt(uni);
         console.log("Amount: "+ total1);
         assert.equal(totalAmounts1, total1);
         browser.sleep(2000);
         assert.equal(unit, uni);
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (totalA) {
                 return console.log("Total Amount : "+ totalA);
                                         });
                                     });
                                   });
                                 });
                             });
                         });
                     });
                 });
              });                      
            });                     
         });     
     });
 });
 },
 validateVariableQuarterlyNoDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Quarterly
               element(by.xpath("//*[@id='228-553-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.Does the rate based on ops range ?---No
               element(by.xpath("//*[@id='230-92-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Quarterly
               element(by.xpath("//*[@id='228-553-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

validateVariableMonthlyNoDifferentRatesForDifferentFuelType:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Monthly
               element(by.xpath("//*[@id='228-552-RADIO']")).click();
               browser.sleep(4000);
                //5.1.1.4.6.Does the rate based on ops range ?---No
               element(by.xpath("//*[@id='230-92-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
               browser.sleep(5000);
               //5.1.1.4.Please select the fees mode---Different rates across different range of operations
               element(by.xpath("//*[@id='59-140-RADIO']")).click();
               browser.sleep(4000);
               element(by.xpath("//*[@id='227-549-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.5.Please select the ops data refresh Frequency---Monthly
               element(by.xpath("//*[@id='228-552-RADIO']")).click();
               browser.sleep(4000);
               //5.1.1.4.6.1.Actual Hours(AH) & Different rates across different range of operations---Add Row
               element(by.xpath("//*[@id='232']/div[5]/div[2]/a")).click();
               browser.sleep(5000);
               element(by.xpath("(//*[@id='232-SELECT']/option[text()='Natural Gas Hours'])[1]")).click();
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")).sendKeys('5');             
               browser.sleep(5000);
               element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
               browser.sleep(11000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

validateDateBasedMilestone:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-129-RADIO']")).click();
                browser.sleep(4000);             
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('200');
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[4]")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Testing');
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                        browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-92-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1--No Fixed Billing
                element(by.xpath("//*[@id='26-296-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                //5.1--No variable billings              
                element(by.xpath("//*[@id='33-129-RADIO']")).click();
                browser.sleep(4000);             
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='124']/div[2]/div[2]/a")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('200');
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                browser.sleep(4000);
                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[1]/td[4]")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Testing');
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                browser.sleep(4000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

verifyDateBasedMilestoneBilling: function () {
    var variable ='ADDER';
    var text = 'Testing';
     browser.driver.sleep(11000);
     return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
         console.log("Billing for Period Header Txt: "+ value);
         browser.driver.sleep(11000);
       cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
  console.log("Entitled Month :", periodDate);
  element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
         console.log("Type: "+ value);
         assert.equal(value, variable);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[1]")).getText().then(function (value) {
         console.log("Description: "+ value);
         assert.equal(value, text);
         browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (totalA) {
                 return console.log("Total Amount : "+ totalA);
                      });
                    });
                });
            });
        });
    });
},

validateMilestoneBillingWidgetDelectRow:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);                
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(9000);
                callback();
                    });
                });
             });
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);                
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[2]")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='deleteRow']")).click();
                browser.sleep(11000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(9000);
            callback();
                   });
                });
            });
        }
    });
},

validateOpsBasedMilestone:function (callback) {
    browser.waitForAngular();
    browser.sleep(12000);
    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
        console.log(value);
        if(value == true || value == "true"){
            browser.sleep(5000); 
            element(by.xpath("//*[@id='createnewversion']")).isPresent();
            //console.log("test123");
            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                browser.sleep(5000);
                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                browser.sleep(3000);
                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                browser.sleep(10000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(6000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
              browser.sleep(4000);
              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1-- Fixed Billing
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(5000);
                //6.1  Operations based milestone billings
                element(by.xpath("//*[@id='84-186-chkbox']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='86']/div[2]/div[2]/a")).click();
                browser.sleep(5000);
                element(by.xpath("(//*[@id='86-SELECT'])[1]/option[3]")).click();
              browser.sleep(3000);
              element(by.xpath("(//*[@id='86-SELECT'])[2]/option[2]")).click();
              browser.sleep(4000);
              element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(CumilativeFFHTxt);
              browser.sleep(4000);
               element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys('600');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Ops Milestone Testing');
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);
                element(by.xpath("//*[@id='commit']")).click();
                browser.sleep(5000);
                console.log("Please confirm to Commit");
                element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                browser.sleep(11000);
                callback();
                                });
                            });
                        });
                    });
                });
             //});
        }else{
            browser.sleep(5000);
            element(by.xpath("//*[@id='commit']")).isPresent();
            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                browser.sleep(6000);
                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                browser.sleep(4000);
                //Selecting Monthly from 2.2 section
                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                browser.sleep(4000);
                //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();             
                browser.sleep(4000);
                element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(4000);                                       
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        }else{
                            console.log("Selected Specified day of the month");
                        }
                browser.sleep(5000);
                element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();               
                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                    console.log(value);
                        if(value==true ){
                        browser.sleep(4000);
                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        }else{
                            console.log("Not associated with Other Contract");
                        }                                                        
                browser.sleep(4000);*/                
                browser.sleep(4000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                browser.sleep(4000);                        
                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                browser.sleep(4000); 
                //2.11 Yes
                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
              browser.sleep(3000);
              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
              browser.sleep(4000);
              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
              browser.sleep(4000);
              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                browser.sleep(6000);
                //4.1-- Fixed Billing
                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(4000);
                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                browser.sleep(4000);
                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                browser.sleep(4000);
                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                browser.sleep(4000);              
                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                browser.sleep(3000);
                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                browser.sleep(3000);
                //5.1.1.4.Please select the fees mode
                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                browser.sleep(3000);
                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                browser.sleep(5000);
                //6.1  Operations based milestone billings
                element(by.xpath("//*[@id='84-186-chkbox']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='86']/div[2]/div[2]/a")).click();
                browser.sleep(5000);
                element(by.xpath("(//*[@id='86-SELECT'])[1]/option[3]")).click();
              browser.sleep(3000);
              element(by.xpath("(//*[@id='86-SELECT'])[2]/option[2]")).click();
              browser.sleep(4000);
              element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("(//*[@id='No. of Hours/Starts-textBox'])[1]")).sendKeys(CumilativeFFHTxt);
              browser.sleep(4000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/input")).sendKeys('600');
              browser.sleep(4000);
              element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                browser.sleep(3000);
                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                browser.sleep(3000);
              element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Ops Milestone Testing');
                browser.sleep(4000);
                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                browser.sleep(11000);
            element(by.xpath("//*[@id='commit']")).click().then(function () {
            browser.sleep(5000);
            console.log("Please confirm to Commit");
            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
            browser.sleep(11000);
            callback();
                       //});
                      });
                   });
                });
            });
        }
    });
},

verifyOpsBasedMilestoneBilling: function () {
    var variable ='ADDER';
    var text = '600.00';
     browser.driver.sleep(11000);
     return element(by.xpath("//*[@id='operationBilling']")).getText().then(function (value) {
         console.log("Billing for Period Header Txt: "+ value);
         browser.driver.sleep(11000);
       cem.findElement(currentPage,'billingCalcInvDateTxt').getText().then(function (periodDate) {
        console.log("Entitled Month :", periodDate);
        element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getText().then(function (value) {
         console.log("PeriodEvent Date: "+ value);
         browser.sleep(2000);
         element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText().then(function (value) {
         console.log("Type: "+ value);
         assert.equal(value, variable);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[1]")).getText().then(function (value) {
         console.log("Description: "+ value);
         element(by.xpath("(//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope'])[4]")).getText().then(function (value) {
         console.log("Amount(USD): "+ value);
         assert.equal(value, text);
         browser.sleep(2000);
             element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'][contains(.,'Total :')])[1]")).getText().then(function (totalA) {
                 return console.log("Total Amount : "+ totalA);
                        });
                      });
                    });
                });
            });
        });
    });
},
  
        };

	};

    module.exports = new TaskMgmtPage();

}());