(function() {
    'use strict';

    var currentPage = 'myFleetPage';
var periodEventDate;
var billingInvoiceDate;
var billingEventPeriodMonth;
var currentDate;
var billingInvoiceAmount;
var invoiceTotalAmount;
var invoiceUnitId;
var invoiceUnitIds;
var equipmentId1;
var equipmentId2;
var projectId1;
var projectId2;
var multiProjectId1;
var multiProjectId2;
var CumilativeFFHTxt;

    var myFleetPage = function() {

        return {
            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            setName: function (username) {
                return cem.findElement(currentPage,'username').sendKeys(username);
            },
            setPassword: function (password) {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'password').sendKeys(password);
            },
            clickLogin: function () {
                return cem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },
            getLogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl);
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
            },

			waitForAssetsTab: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(11000);
			 return TestHelper.isElementPresent(currentPage,'assetsTab');
            },

            assetsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'assetsTab').click();
            },

            enterSSO: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'loginUsername').sendKeys('503114663');
            },

            loginButton: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return cem.findElement(currentPage,'loginButton').click();
            },

            myContactsSearchOptn: function (contractId) {
                browser.waitForAngular();
                browser.driver.sleep(11000);
                TestHelper.isElementPresent(currentPage,'myContactsSearchFld');
                browser.driver.sleep(6000);
                return cem.findElement(currentPage,'myContactsSearchFld').sendKeys(contractId);
            },

            validateAddrowFixedBilling:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(7000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(6000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                            browser.sleep(4000);
                            //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            //browser.sleep(5000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);                                       
                            element(by.xpath("//*[@id='93-256-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    }else{
                                        console.log("Selected Specified day of the month");
                                    }
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                            /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/                
                            browser.sleep(4000);
                            //2.8--No
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);                        
                            element(by.xpath("//*[@id='20-91-RADIO']")).click();
                            browser.sleep(4000); 
                            //2.11 Yes
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                          browser.sleep(3000);
                          element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                          browser.sleep(4000);
                          element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                          browser.sleep(4000);
                          element(by.xpath("//*[@id='106-326-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='107-329-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(6000);
                            //4.1-- Fixed Billing
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            //4.3. Are any Fixed billings subject to Monetization?--Yes
                            element(by.xpath("//*[@id='118-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='119']/div[5]/div[2]/a[1]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                            browser.sleep(4000);
                            element(by.xpath("(//*[@id='119-1-monetize'])[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                            browser.sleep(11000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);              
                            element(by.xpath("//*[@id='33-127-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                            browser.sleep(3000);
                            //5.1.1.4.Please select the fees mode
                            element(by.xpath("//*[@id='35-137-RADIO']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                    }else{
                                        console.log("Already selected No Milestone option");
                                    }                                                        
                            browser.sleep(5000);                            
                            element(by.xpath("//*[@id='saveasdraft']")).click();
                            browser.sleep(5000);
                            console.log("Please do Save as draft");
                            element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                            browser.sleep(11000);
                            callback();
                                            });
                                        });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(6000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(7000);                            
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                            browser.sleep(4000);
                            //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                            //browser.sleep(5000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);                                       
                            element(by.xpath("//*[@id='93-256-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    }else{
                                        console.log("Selected Specified day of the month");
                                    }
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                            /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/                
                            browser.sleep(4000);
                            //2.8--No
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);                        
                            element(by.xpath("//*[@id='20-91-RADIO']")).click();
                            browser.sleep(4000); 
                            //2.11 Yes
                            element(by.xpath("//*[@id='125-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                          browser.sleep(3000);
                          element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                          browser.sleep(4000);
                          element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                          browser.sleep(4000);
                          element(by.xpath("//*[@id='106-326-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='107-329-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(6000);
                            //4.1-- Fixed Billing
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            //4.3. Are any Fixed billings subject to Monetization?--Yes
                            element(by.xpath("//*[@id='118-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='119']/div[5]/div[2]/a[1]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                            browser.sleep(4000);
                            element(by.xpath("(//*[@id='119-1-monetize'])[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                            browser.sleep(11000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);              
                            element(by.xpath("//*[@id='33-127-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                            browser.sleep(3000);
                            //5.1.1.4.Please select the fees mode
                            element(by.xpath("//*[@id='35-137-RADIO']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                    }else{
                                        console.log("Already selected No Milestone option");
                                    }                                                        
                            browser.sleep(5000);                            
                            element(by.xpath("//*[@id='saveasdraft']")).click();
                            browser.sleep(5000);
                            console.log("Please do Save as draft");
                            element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                        browser.sleep(11000);
                        callback();
                                   //});
                                  });
                               });
                            });
                        });
                    }
                });
            },

            validateFixedDeleteBtn:function (callback) {
                browser.sleep(9000);
                var elm = element.all(by.xpath("(//*[@class='glyphicon glyphicon-trash'])")).isPresent().then(function(){
                    browser.sleep(3000); 
                    element(by.xpath("(//*[@class='glyphicon glyphicon-trash'])[7]")).click();
                    //var ele = element.all(by.xpath("(//*[@class='glyphicon glyphicon-trash'])")).last();  
                //ele.click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='deleteConfirmPopup']/div/div/div[3]/a")).click(); 
                    callback();
                });
            },

            validateFixedEditBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(6000);
                //element.all(by.xpath("(//*[@class='glyphicon glyphicon-pencil'])")).isPresent();
                browser.driver.sleep(2000);
                element(by.xpath("(//*[@class='glyphicon glyphicon-pencil'])[12]")).click();
                //var ele =  element.all(by.xpath("(//*[@class='glyphicon glyphicon-pencil'])")).last();
                 //ele.click();
                 browser.driver.sleep(4000);
                return element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/a")).click();
              },

            /*validateEditBtn:function (callback) {
                browser.sleep(8000);
                var elm = element.all(by.xpath("(//*[@class='glyphicon glyphicon-pencil'])")).isPresent().then(function () {
                    browser.sleep(3000);
                var ele = element.all(by.xpath("(//*[@class='glyphicon glyphicon-pencil'])")).last();
                    ele.click();
                    browser.sleep(4000);
                    element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/a")).click(); 
                    callback();
                });
            },*/

            myContactsCommitBtn: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                cem.findElement(currentPage,'myContactsCommitBtn').click();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'myContactsConformationCommitBtn').click();                
                return browser.driver.sleep(9000);
                 },

                 validateAddrowVariableMonetizationBilling:function (callback) {
                    browser.waitForAngular();
                    browser.sleep(12000);
                    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                        console.log(value);
                        if(value == true || value == "true"){
                            browser.sleep(5000); 
                            element(by.xpath("//*[@id='createnewversion']")).isPresent();
                            //console.log("test123");
                            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                                browser.sleep(10000);
                                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(6000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                                browser.sleep(4000);
                                //4.3. Are any Fixed billings subject to Monetization?--No
                                element(by.xpath("//*[@id='118-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='121']/div[5]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Jan Month selection
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Jan Month selection
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='121-1-monetize'])[1]")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000);
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                        }else{
                                            console.log("Already selected No Milestone option");
                                        }                                                        
                                browser.sleep(5000);                            
                                element(by.xpath("//*[@id='saveasdraft']")).click();
                                browser.sleep(5000);
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                                callback();
                                                });
                                            });
                                        });
                                    });
                                });
                             });
                        }else{
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).isPresent();
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);                            
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                                browser.sleep(4000);
                                //4.3. Are any Fixed billings subject to Monetization?--No
                                element(by.xpath("//*[@id='118-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='121']/div[5]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='121-1-monetize'])[1]")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000);
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                        }else{
                                            console.log("Already selected No Milestone option");
                                        }                                                        
                                browser.sleep(5000);                            
                                element(by.xpath("//*[@id='saveasdraft']")).click();
                                browser.sleep(5000);
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                            callback();
                                       //});
                                      });
                                   });
                                });
                            });
                        }
                    });
                },

                validateAddrowMilestoneMonetizationBilling:function (callback) {
                    browser.waitForAngular();
                    browser.sleep(12000);
                    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                        console.log(value);
                        if(value == true || value == "true"){
                            browser.sleep(5000); 
                            element(by.xpath("//*[@id='createnewversion']")).isPresent();
                            //console.log("test123");
                            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                                browser.sleep(10000);
                                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(6000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                                browser.sleep(4000);
                                //4.3. Are any Fixed billings subject to Monetization?--No
                                element(by.xpath("//*[@id='118-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='122-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='123']/div[2]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                                browser.sleep(4000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[4]")).click();
                                browser.sleep(3000);                                
                                element(by.xpath("//*[@id='123-milestoneMonetize']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Testing');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000); 
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                                callback();
                                                //});
                                            });
                                        });
                                    });
                                });
                             });
                        }else{
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).isPresent();
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);                            
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                                element(by.xpath("//*[@id='26-104-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(4000);
                                element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='99-92-RADIO']")).click();
                                browser.sleep(4000);
                                //4.3. Are any Fixed billings subject to Monetization?--No
                                element(by.xpath("//*[@id='118-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-92-RADIO']")).click();
                                browser.sleep(4000);                                
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='84-187-chkbox']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='122-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='123']/div[2]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/thead/tr[1]/th[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                                browser.sleep(4000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[1]/table/tbody/tr[5]/td[4]")).click();
                                browser.sleep(3000);                                
                                element(by.xpath("//*[@id='123-milestoneMonetize']")).click();
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("(//*[@id='Description-textBox'])[1]")).sendKeys('Testing');
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000);                            
                                element(by.xpath("//*[@id='saveasdraft']")).click();
                                browser.sleep(5000);
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                            callback();
                                       //});
                                      //});
                                   });
                                });
                            });
                        }
                    });
                },

                monetizationTab: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(8000);
                    return cem.findElement(currentPage,'monetizationTab').click();
                },

                waitFormonetizationTab: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(8000);
                    return TestHelper.isElementPresent(currentPage,'myContactsSearchFld');

                },

                monetizationContractIDLbl: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationContractIDLbl').getText();
                },
                monetizationContractID: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationContractID').getText();
                },

                monetizationModelIDLbl: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationModelIDLbl').getText();
                },

                monetizationModelID: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationModelID').getText();
                },

                monetizationCustomerNameLbl: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationCustomerNameLbl').getText();
                },
                
                monetizationCustName: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationCustName').getText();
                },
                monetizationSiteNameLbl: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationSiteNameLbl').getText();
                },
                
                monetizationSiteName: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationSiteName').getText();
                },

                monetizationBillingTypeOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationBillingTypeOption').getText();
                },
                 
                monetizationProjectIdOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationProjectIdOption').getText();
                },

                monetizationPeriodEventOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationPeriodEventOption').getText();
                },

                monetizationMonetizedAmountOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationMonetizedAmountOption').getText();
                },

                monetizationInvoiceDateOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationInvoiceDateOption').getText();
                },
                monetizationPaymentTermsOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationPaymentTermsOption').getText();
                },
                monetizationAlphaProvisionalInvoiceOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationAlphaProvisionalInvoiceOption').getText();
                },

                monetizationBillingStatusOption: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationBillingStatusOption').getText();
                },

                monetizationDataValidation: function (callback) {
                    browser.waitForAngular();
                    browser.driver.sleep(15000);
                    element.all(by.xpath("//*[@id='DataTables_Table_0']/tbody/tr[1]/td")).count().then(function(levelOneCount){
                    //console.log("Total number of Elements: "+ JSON.stringify(levelOneCount));
                    browser.sleep(3000);
                    for (var i=1; i<=8; i++){
                        browser.waitForAngular();
                        browser.driver.sleep(2000);
                        //console.log("Entered into for loop " +i);                        
                        var text = element.all(by.xpath("//*[@id='DataTables_Table_0']/tbody/tr[1]/td[" + i + "]")).getText();
                          console.log("Records details: " + text);
                        }
                        callback(); 
                   });
                   
                },

                monetizationBillingBackBtn: function () {
                    browser.waitForAngular();
                    browser.driver.sleep(4000);
                    return cem.findElement(currentPage,'monetizationBillingBackBtn').click();
                },

                monetizationMANLNumber: function () {
                    browser.driver.sleep(5000);
                    var actual ='MANL';
                    return cem.findElement(currentPage,'monetizationMANLNumber').getText().then(function (value) {
                    var text = value.split(new RegExp('-'));    
                    console.log(text[0]==actual);              
                      
                    });
                
                },

                validateAddrowFixedAndVariableMonetizationBilling:function (callback) {
                    browser.waitForAngular();
                    browser.sleep(12000);
                    element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                        console.log(value);
                        if(value == true || value == "true"){
                            browser.sleep(5000); 
                            element(by.xpath("//*[@id='createnewversion']")).isPresent();
                            //console.log("test123");
                            element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                                browser.sleep(10000);
                                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(6000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            //4.3. Are any Fixed billings subject to Monetization?--Yes
                            element(by.xpath("//*[@id='118-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='119']/div[5]/div[2]/a[1]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                            browser.sleep(4000);
                            element(by.xpath("(//*[@id='119-1-monetize'])[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                            browser.sleep(11000);                               
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='121']/div[5]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Feb Month selection
                                element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='121-1-monetize'])[1]")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000);
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                        }else{
                                            console.log("Already selected No Milestone option");
                                        }                                                        
                                browser.sleep(5000);                            
                                element(by.xpath("//*[@id='saveasdraft']")).click();
                                browser.sleep(5000);
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                                callback();
                                                });
                                            });
                                        });
                                    });
                                });
                             });
                        }else{
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='commit']")).isPresent();
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                                browser.sleep(6000);
                                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                                browser.sleep(7000);                            
                                element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.2 section
                                element(by.xpath("//*[@id='2-4-RADIO']")).click();
                                browser.sleep(4000);
                                //Selecting Monthly from 2.3 section
                                element(by.xpath("//*[@id='3-8-RADIO']")).click();             
                                browser.sleep(4000);
                                //element(by.xpath("//*[@id='4-SELECT']/option[text()='0']")).click();
                                //browser.sleep(5000);
                                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                browser.sleep(4000);                                       
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='14-232-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                        }else{
                                            console.log("Selected Specified day of the month");
                                        }
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();               
                                /* element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                        }else{
                                            console.log("Not associated with Other Contract");
                                        }                                                        
                                browser.sleep(4000);*/                
                                browser.sleep(4000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(4000);                        
                                element(by.xpath("//*[@id='20-91-RADIO']")).click();
                                browser.sleep(4000); 
                                //2.11 Yes
                                element(by.xpath("//*[@id='125-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                              browser.sleep(3000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys(protractor.Key.DELETE);
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='Escalation Rate']")).sendKeys('.25');
                              browser.sleep(4000);
                              element(by.xpath("//*[@id='106-326-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='107-329-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                                browser.sleep(6000);
                                //4.1-- Fixed Billing
                              element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            //4.3. Are any Fixed billings subject to Monetization?--Yes
                            element(by.xpath("//*[@id='118-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='119']/div[5]/div[2]/a[1]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                            browser.sleep(4000);
                            element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[1]")).click();
                            browser.sleep(3000);
                            //Feb Month selection
                            element(by.xpath("/html/body/div[9]/div[2]/table/tbody/tr/td/span[2]")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                            browser.sleep(4000);
                            element(by.xpath("(//*[@id='119-1-monetize'])[1]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                            browser.sleep(11000);                                
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(4000);              
                                element(by.xpath("//*[@id='33-127-RADIO']")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='34-SELECT']/option[text()='Factored Fired Hours (FFH)']")).click();
                                browser.sleep(3000);
                                //5.1.1.4.Please select the fees mode
                                element(by.xpath("//*[@id='35-137-RADIO']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='36']/div[5]/div/table/tbody/tr/td[2]/input")).sendKeys('10');
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='120-91-RADIO']")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='121']/div[5]/div[2]/a[1]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Jan Month selection
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button/i")).click();
                                browser.sleep(4000);
                                element(by.xpath("/html/body/div[9]/div[2]/table/thead/tr/th[2]")).click();
                                browser.sleep(3000);
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(3000);
                                //Jan Month selection
                                element(by.xpath("/html/body/div[9]/div[3]/table/tbody/tr/td/span[10]")).click();
                                browser.sleep(4000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys(protractor.Key.DELETE);
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[5]/td[2]/input")).sendKeys('600');
                                browser.sleep(4000);
                                element(by.xpath("(//*[@id='121-1-monetize'])[1]")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")).click();
                                browser.sleep(11000);
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(5000);
                                element(by.xpath("//*[@id='84-605-chkbox']")).getAttribute('checked').then(function(value){
                                    console.log(value);
                                        if(value==true ){
                                        browser.sleep(4000);
                                        element(by.xpath("//*[@id='84-605-chkbox']")).click();
                                        }else{
                                            console.log("Already selected No Milestone option");
                                        }                                                        
                                browser.sleep(5000);                            
                                element(by.xpath("//*[@id='saveasdraft']")).click();
                                browser.sleep(5000);
                                console.log("Please do Save as draft");
                                element(by.xpath("//*[@id='confirmid2']")).click().then(function () {
                                browser.sleep(11000);
                            callback();
                                       //});
                                      });
                                   });
                                });
                            });
                        }
                    });
                },
                

            
        };

	};

    module.exports = new myFleetPage();

}());